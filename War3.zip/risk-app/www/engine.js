/* موتور امتیازدهی و تأیید خبر — منطق خالص، بدون وابستگی به صفحه */
(function (root) {
'use strict';

const BASE_RISK = 30;      // نمره پایه: جنگ هنوز تمام نشده و آتش‌بس شکننده است
const PT = 4;              // هر امتیاز خبری چند واحد ریسک است
const HALF_LIFE_H = 12;    // نیمه‌عمر اثر هر خبر (ساعت)
const HOUR = 3600e3, MIN = 60e3;

const GN = q => 'https://news.google.com/rss/search?q=' + q + '&hl=en-US&gl=US&ceid=US:en';
const GNFA = q => 'https://news.google.com/rss/search?q=' + q + '&hl=fa&gl=IR&ceid=IR:fa';
const SOURCES = [
  // every = هر چند دقیقه یک بار خوانده شود (جستجوهای گوگل کمتر، تا مسدود نشوند)
  { id:'reuters', name:'رویترز', group:'reuters', every:2, strip:true, url:GN('Iran+when:1d+site:reuters.com') },
  { id:'ap',      name:'AP',     group:'ap',      every:2, strip:true, url:GN('Iran+when:1d+site:apnews.com') },
  { id:'bbcen',   name:'BBC (انگلیسی)', group:'bbc', every:2, strip:true, url:GN('Iran+when:1d+site:bbc.com') },
  { id:'bbcfa',   name:'BBC فارسی', group:'bbc',   every:2, strip:true, url:GNFA('site:bbc.com/persian+when:1d') },
  { id:'aljaz',   name:'الجزیره', group:'aljazeera', every:1, url:'https://www.aljazeera.com/xml/rss/all.xml' },
  { id:'irna',    name:'ایرنا',   group:'irna',    every:1, url:'https://www.irna.ir/rss' },
  { id:'isna',    name:'ایسنا',   group:'isna',    every:1, url:'https://www.isna.ir/rss' },
  { id:'mehr',    name:'مهر',     group:'mehr',    every:1, url:'https://www.mehrnews.com/rss' },
  { id:'tasnim',  name:'تسنیم',   group:'tasnim',  every:2, strip:true, url:GNFA('site:tasnimnews.com+when:1d') },
  { id:'fars',    name:'فارس',    group:'fars',    every:2, strip:true, url:GNFA('site:farsnews.ir+when:1d') },
  // جستجوهای موضوعی (از میان رسانه‌های معتبر فهرست‌شده)
  { id:'gn_emb',  name:'جستجو: سفارتخانه‌ها', gnews:true, every:3, url:GN('Iran+(embassy+OR+%22ordered+departure%22+OR+%22travel+advisory%22+OR+evacuation)+when:2d') },
  { id:'gn_air',  name:'جستجو: آسمان و پرواز', gnews:true, every:3, url:GN('Iran+(airspace+OR+NOTAM+OR+%22flights+suspended%22)+when:2d') },
  { id:'gn_str',  name:'جستجو: حمله و انفجار', gnews:true, every:3, url:GN('Iran+(strike+OR+explosion+OR+attack)+when:1d') },
  { id:'gn_rus',  name:'جستجو: تخلیه روسیه و بوشهر', gnews:true, every:3, url:GN('Bushehr+OR+Rosatom+evacuate+when:3d') },
  { id:'gn_fa',   name:'جستجو: فارسی', gnews:true, every:3, url:GNFA('%D8%A7%DB%8C%D8%B1%D8%A7%D9%86+%D8%AD%D9%85%D9%84%D9%87+OR+%D8%A7%D9%86%D9%81%D8%AC%D8%A7%D8%B1+when:1d') },
];
const PUB_GROUPS = [ [/reuters|رویترز/, 'reuters'], [/associated press|^ap$|\bap news/, 'ap'], [/bbc|بی.?بی.?سی/, 'bbc'], [/al jazeera|aljazeera|الجزیره/, 'aljazeera'],
  [/afp/, 'afp'], [/cnn/, 'cnn'], [/axios/, 'axios'], [/jerusalem post/, 'jpost'], [/times of israel/, 'toi'], [/bloomberg/, 'bloomberg'],
  [/irna|ایرنا/, 'irna'], [/isna|ایسنا/, 'isna'], [/mehr|مهر/, 'mehr'], [/tasnim|تسنیم/, 'tasnim'], [/fars|فارس/, 'fars'] ];
function pubGroup(pub) {
  const n = String(pub || '').toLowerCase();
  for (const [re, g] of PUB_GROUPS) if (re.test(n)) return g;
  return n.replace(/[^a-z0-9\u0600-\u06ff]/g, '');
}
// منابع ایرانی: خبر جنگ را بیشتر و پررنگ‌تر پوشش می‌دهند، پس اثرشان کمتر حساب می‌شود
const IR_SOURCE = /irna|isna|mehr|tasnim|fars|ایرنا|ایسنا|مهر|تسنیم|فارس|press ?tv|tehran times|kayhan|کیهان|مشرق|mashregh|young journalists|باشگاه خبرنگاران/i;

// فقط این ناشرها از جستجوهای موضوعی پذیرفته می‌شوند (ایران اینترنشنال و سایت‌های زرد عمداً نیستند)
const TRUSTED_PUB = /reuters|associated press|^ap$|\bap news|bbc|al jazeera|aljazeera|afp|france 24|dw\b|deutsche welle|cnn|new york times|washington post|guardian|bloomberg|axios|wall street journal|times of israel|jerusalem post|irna|isna|mehr|tasnim|fars|ایرنا|ایسنا|مهر|تسنیم|فارس|بی.?بی.?سی|الجزیره|رویترز/i;


const INDICATORS = [
  { id:'news',     name:'اخبار و دیپلماسی',          weight:18, available:true },
  { id:'airspace', name:'آسمان (خبرها و اعلان رسمی)', weight:16, available:true },
  { id:'flights',  name:'ترافیک هوایی زنده',         weight:14, available:true },
  { id:'embassy',  name:'سفارتخانه‌ها و هشدار سفر',  weight:20, available:true },
  { id:'military', name:'نیروی نظامی و دفاع غیرنظامی', weight:14, available:true },
  { id:'civil',    name:'پدافند غیرعامل و وضعیت داخلی', weight:10, available:true },
  { id:'markets',  name:'بازارهای مالی و انرژی',     weight:10, available:true },
  { id:'crowd',    name:'بازار پیش‌بینی (Polymarket)', weight:8, available:true },
  { id:'tone',     name:'لحن اظهارات رهبران آمریکا و اسرائیل', weight:6, available:true },
  { id:'internet', name:'اینترنت',                   weight:8,  available:true },
];

/* ---------- متن ---------- */
function norm(s) {
  return String(s || '')
    .replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/ة/g, 'ه')
    .replace(/[\u200c\u200f\u200e]/g, ' ')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
    .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))
    .toLowerCase();
}
function unent(s) {
  return s.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"')
    .replace(/&#39;|&apos;/g,"'").replace(/&nbsp;/g,' ')
    .replace(/&#(\d+);/g,(m,n)=>String.fromCharCode(+n)).replace(/&amp;/g,'&');
}
function stripHtml(s) {
  s = String(s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1');
  s = unent(s).replace(/<[^>]+>/g, ' ');
  return unent(s).replace(/\s+/g, ' ').trim();
}
function tag(block, name) {
  const m = block.match(new RegExp('<' + name + '(?:\\s[^>]*)?>([\\s\\S]*?)</' + name + '>', 'i'));
  return m ? m[1] : '';
}
function parseFeed(xml, src) {
  const out = [];
  const blocks = xml.match(/<item[\s>][\s\S]*?<\/item>|<entry[\s>][\s\S]*?<\/entry>/gi) || [];
  for (const b of blocks) {
    const title = stripHtml(tag(b, 'title'));
    if (!title) continue;
    let link = stripHtml(tag(b, 'link'));
    if (!link) { const m = b.match(/<link[^>]*href=["']([^"']+)["']/i); link = m ? unent(m[1]) : ''; }
    const body = stripHtml(tag(b, 'description') || tag(b, 'summary') || tag(b, 'content'));
    const d = new Date(stripHtml(tag(b, 'pubDate') || tag(b, 'published') || tag(b, 'updated') || tag(b, 'dc:date')));
    let source = src.name, group = src.group, t = title;
    const pub = stripHtml(tag(b, 'source'));
    if (src.gnews) {
      if (!pub || !TRUSTED_PUB.test(pub)) continue;
      source = pub; group = pubGroup(pub);
    } else if (src.strip && pub) {
      // نتیجه جستجوی «site:bbc.com» فقط وقتی «BBC» است که ناشر واقعی هم BBC باشد
      const g = pubGroup(pub);
      if (g !== src.group) { if (TRUSTED_PUB.test(pub)) { source = pub; group = g; } else continue; }
    }
    if ((src.gnews || src.strip) && pub && t.endsWith(' - ' + pub)) t = t.slice(0, -(pub.length + 3));
    else if (src.strip) t = t.replace(/\s+-\s+[^-]{2,40}$/, '');
    out.push({
      title: t, link, body, ts: isNaN(d) ? null : d.getTime(),
      source, group, fullText: false,
    });
  }
  return out;
}
function extractArticleText(html) {
  let h = String(html || '').replace(/<(script|style|nav|footer|header|aside|form)[\s\S]*?<\/\1>/gi, ' ');
  const ps = (h.match(/<p[\s>][\s\S]*?<\/p>/gi) || []).map(stripHtml).filter(t => t.length > 40);
  let text = ps.join('\n');
  if (text.length < 200) {
    const m = h.match(/<meta[^>]+(?:property=["']og:description["']|name=["']description["'])[^>]+content=["']([^"']+)["']/i);
    if (m) text = stripHtml(m[1]) + '\n' + text;
  }
  return text.slice(0, 6000);
}

/* ---------- استان‌ها و شهرها ---------- */
// هر مکان: [شناسه، نام فارسی، الگو]. استان‌های «تهران» و «البرز» پیش‌فرضِ آلارم ویژه هستند.
const PROVINCES = [
  { id: 'tehran', fa: 'تهران', places: [['Tehran', 'تهران', /tehran|تهران/], ['Parchin', 'پارچین', /parchin|پارچین/], ['Shahriar', 'شهریار', /shahriar|شهریار/], ['Eslamshahr', 'اسلامشهر', /eslamshahr|islamshahr|اسلامشهر/], ['Varamin', 'ورامین', /varamin|ورامین/], ['Pakdasht', 'پاکدشت', /pakdasht|پاکدشت/], ['Damavand', 'دماوند', /damavand|دماوند/], ['Rey', 'شهر ری', /\bray\b|شهر ری/], ['RobatKarim', 'رباط‌کریم', /robat karim|رباط.?کریم/], ['Pardis', 'پردیس', /pardis|پردیس/], ['Parand', 'پرند', /parand|پرند/], ['Firuzkuh', 'فیروزکوه', /firuzkuh|فیروزکوه/], ['Lavasan', 'لواسان', /lavasan|لواسان/]] },
  { id: 'alborz', fa: 'البرز', places: [['Karaj', 'کرج', /karaj|کرج/], ['Fardis', 'فردیس', /fardis|فردیس/], ['Nazarabad', 'نظرآباد', /nazarabad|نظرآباد/], ['Hashtgerd', 'هشتگرد', /hashtgerd|هشتگرد|savojbolagh|ساوجبلاغ/], ['Taleqan', 'طالقان', /taleqan|طالقان/], ['Eshtehard', 'اشتهارد', /eshtehard|اشتهارد/], ['Mehrshahr', 'مهرشهر', /mehrshahr|مهرشهر/], ['AlborzProv', 'استان البرز', /alborz province|استان البرز|\balborz\b|البرز/]] },
  { id: 'isfahan', fa: 'اصفهان', places: [['Isfahan', 'اصفهان', /isfahan|esfahan|اصفهان/], ['Natanz', 'نطنز', /natanz|نطنز/], ['Kashan', 'کاشان', /kashan|کاشان/], ['Najafabad', 'نجف‌آباد', /najafabad|نجف.?آباد/], ['ShahinShahr', 'شاهین‌شهر', /shahin ?shahr|شاهین.?شهر/]] },
  { id: 'qom', fa: 'قم', places: [['Qom', 'قم', /\bqom\b|\bqum\b|قم/], ['Fordow', 'فردو', /fordow|fordo|فردو/]] },
  { id: 'markazi', fa: 'مرکزی', places: [['Arak', 'اراک', /\barak\b|اراک/], ['Khondab', 'خنداب', /khondab|خنداب/], ['Saveh', 'ساوه', /saveh|ساوه/]] },
  { id: 'qazvin', fa: 'قزوین', places: [['Qazvin', 'قزوین', /qazvin|قزوین/]] },
  { id: 'zanjan', fa: 'زنجان', places: [['Zanjan', 'زنجان', /zanjan|زنجان/]] },
  { id: 'semnan', fa: 'سمنان', places: [['Semnan', 'سمنان', /semnan|سمنان/], ['Shahroud', 'شاهرود', /shahroud|شاهرود/], ['Garmsar', 'گرمسار', /garmsar|گرمسار/]] },
  { id: 'mazandaran', fa: 'مازندران', places: [['Sari', 'ساری', /\bsari\b|ساری/], ['Babol', 'بابل', /babol|بابل/], ['Amol', 'آمل', /\bamol\b|آمل/], ['Nowshahr', 'نوشهر', /nowshahr|نوشهر/]] },
  { id: 'gilan', fa: 'گیلان', places: [['Rasht', 'رشت', /rasht|رشت/], ['BandarAnzali', 'بندر انزلی', /anzali|انزلی/]] },
  { id: 'golestan', fa: 'گلستان', places: [['Gorgan', 'گرگان', /gorgan|گرگان/]] },
  { id: 'razavi', fa: 'خراسان رضوی', places: [['Mashhad', 'مشهد', /mashhad|مشهد/], ['Neyshabur', 'نیشابور', /neyshabur|nishapur|نیشابور/], ['Sabzevar', 'سبزوار', /sabzevar|سبزوار/]] },
  { id: 'nkhorasan', fa: 'خراسان شمالی', places: [['Bojnord', 'بجنورد', /bojnord|بجنورد/]] },
  { id: 'skhorasan', fa: 'خراسان جنوبی', places: [['Birjand', 'بیرجند', /birjand|بیرجند/]] },
  { id: 'yazd', fa: 'یزد', places: [['Yazd', 'یزد', /\byazd\b|یزد/]] },
  { id: 'kerman', fa: 'کرمان', places: [['Kerman', 'کرمان', /\bkerman\b|کرمان(?!شاه)/], ['Bam', 'بم', /\bbam\b/], ['Jiroft', 'جیرفت', /jiroft|جیرفت/], ['Rafsanjan', 'رفسنجان', /rafsanjan|رفسنجان/]] },
  { id: 'sistan', fa: 'سیستان و بلوچستان', places: [['Zahedan', 'زاهدان', /zahedan|زاهدان/], ['Chabahar', 'چابهار', /chabahar|چابهار/], ['Zabol', 'زابل', /zabol|زابل/], ['Konarak', 'کنارک', /konarak|کنارک/]] },
  { id: 'hormozgan', fa: 'هرمزگان', places: [['BandarAbbas', 'بندر عباس', /bandar abbas|بندر عباس/], ['Qeshm', 'قشم', /qeshm|قشم/], ['Minab', 'میناب', /minab|میناب/], ['Jask', 'جاسک', /\bjask\b|جاسک/], ['BandarLengeh', 'بندر لنگه', /bandar lengeh|لنگه/], ['Kish', 'کیش', /\bkish\b|جزیره کیش/], ['Abu Musa', 'ابوموسی', /abu musa|ابوموسی/]] },
  { id: 'fars', fa: 'فارس', places: [['Shiraz', 'شیراز', /shiraz|شیراز/], ['Marvdasht', 'مرودشت', /marvdasht|مرودشت/], ['Jahrom', 'جهرم', /jahrom|جهرم/]] },
  { id: 'bushehr', fa: 'بوشهر', places: [['Bushehr', 'بوشهر', /bushehr|بوشهر/], ['Asaluyeh', 'عسلویه', /asaluyeh|عسلویه/], ['Kharg', 'خارک', /kharg|خارک/], ['Genaveh', 'بندر گناوه', /genaveh|گناوه/]] },
  { id: 'khuzestan', fa: 'خوزستان', places: [['Ahvaz', 'اهواز', /ahvaz|اهواز/], ['Abadan', 'آبادان', /abadan|آبادان/], ['Khorramshahr', 'خرمشهر', /khorramshahr|خرمشهر/], ['Dezful', 'دزفول', /dezful|دزفول/], ['Mahshahr', 'ماهشهر', /mahshahr|ماهشهر/], ['BandarImam', 'بندر امام', /bandar.?e? imam|بندر امام/]] },
  { id: 'kohgiluyeh', fa: 'کهگیلویه و بویراحمد', places: [['Yasuj', 'یاسوج', /yasuj|یاسوج/]] },
  { id: 'chaharmahal', fa: 'چهارمحال و بختیاری', places: [['Shahrekord', 'شهرکرد', /shahrekord|شهرکرد/]] },
  { id: 'lorestan', fa: 'لرستان', places: [['Khorramabad', 'خرم‌آباد', /khorramabad|خرم.?آباد/]] },
  { id: 'ilam', fa: 'ایلام', places: [['Ilam', 'ایلام', /\bilam\b|ایلام/]] },
  { id: 'kermanshah', fa: 'کرمانشاه', places: [['Kermanshah', 'کرمانشاه', /kermanshah|کرمانشاه/]] },
  { id: 'kurdistan', fa: 'کردستان', places: [['Sanandaj', 'سنندج', /sanandaj|سنندج/]] },
  { id: 'hamedan', fa: 'همدان', places: [['Hamedan', 'همدان', /hamedan|همدان/]] },
  { id: 'eazerbaijan', fa: 'آذربایجان شرقی', places: [['Tabriz', 'تبریز', /tabriz|تبریز/], ['Maragheh', 'مراغه', /maragheh|مراغه/]] },
  { id: 'wazerbaijan', fa: 'آذربایجان غربی', places: [['Urmia', 'ارومیه', /urmia|ارومیه/], ['Mahabad', 'مهاباد', /mahabad|مهاباد/]] },
  { id: 'ardabil', fa: 'اردبیل', places: [['Ardabil', 'اردبیل', /ardabil|اردبیل/]] },
];
const PLACE_FA = { Iran: 'ایران' };
const PLACE_PROV = {};
PROVINCES.forEach(p => p.places.forEach(([id, fa]) => { PLACE_FA[id] = fa; PLACE_PROV[id] = p.id; }));
const DEFAULT_WATCH = ['tehran', 'alborz'];
function provinceOf(placeId) { return PLACE_PROV[placeId] || null; }

/* ---------- الگوهای زبان ---------- */
const GENERIC_IRAN = /(strikes?|attacks?|attacked|bombing|bombed|missiles?|explosions?)\s+(on|against|in|inside|across)\s+iran|inside iran|across iran|حمله\s+(به|علیه)\s+ایران|در\s+(سراسر|داخل)\s+ایران/;

const ATTACK = new RegExp([
  'air ?strikes?', 'strikes? (?:on|against|hit|hits|rocked)', 'strikes?\\s+(?:\\w+\\s+){0,3}(?:on|against)\\b', '\\bstruck\\b', 'bombed', 'bombing', 'explosions?', 'blasts?',
  'missiles? (?:hit|struck|landed|slammed)', 'rockets? (?:hit|struck)', 'shelling', 'attacked', 'attack on',
  '(?:us|u\\.s\\.|american|israeli?|military|forces|jets?)\\s+strikes?\\s+(?!a\\b|an\\b|deal|balance|agreement|pose)',
  'حمله هوایی', 'حمله', 'بمباران', 'موشک.?باران', 'انفجار', 'اصابت', 'موشک.{0,15}(?:اصابت|فرود|شلیک شد)', 'پدافند.{0,15}فعال'
].join('|'));

const HYPO = new RegExp([
  '\\bif\\b', '\\bcould\\b', '\\bwould\\b', '\\bmay\\b', '\\bmight\\b', 'warns?\\b', 'warned', 'threat', 'scenario',
  'fears?\\b', 'risk of', 'hypothetical', 'drills?\\b', 'exercises?\\b', 'simulat', 'what happens', 'what if', 'prepare for',
  'اگر', 'در صورت', 'چنانچه', 'هر ?گونه', 'احتمال', 'ممکن است', 'می‌تواند', 'میتواند', 'تهدید', 'سناریو', 'هشدار داد', 'رزمایش', 'مانور',
  'شبیه.?سازی', 'چه می.?شود', 'چه اتفاقی', 'اگه'
].join('|'));

// «نه، هیچ، ندارم…»: انکار و نفی
const NEG = /\b(no|not|never|none|won'?t|wouldn'?t|don'?t|doesn'?t|didn'?t|isn'?t|aren'?t|hasn'?t|haven'?t|without|denies|denied|deny|denying|rules? out|ruled out|unlikely|refus\w+)\b|هیچ|ندارد|ندارم|ندارند|نخواهد|نمی.?کند|نمی.?کنم|نمی.?شود|نشده|نکرد|نیست|نبود|بدون|تکذیب|رد کرد|قصد ندارد|برنامه.?ای ندارد|خبری از/;
// برنامه، قصد، تهدید و آینده: «رویداد» نیست
const INTENT = /\b(plans?|planning|planned|intend\w*|prepar\w+|ready to|readying|threat\w*|will|going to|considering|weigh\w*|mull\w*|set to|poised|eyes?|eyeing|urges?|calls? (on|for)|vows?|pledges?|promis\w+|warns?|expects?|likely|possible|possibility|risk|demands?)\b|برنامه|قصد|آماده|تهدید|خواهد|می.?خواهد|در نظر دارد|بررسی می.?کند|احتمال|ممکن است|وعده|هشدار|تصمیم دارد|خواستار/;
// فعل رویداد: چیزی واقعاً رخ داده یا گزارش شده
const EVENT = /\b(?:us|u\.s\.|american|israeli?|military|forces|jets?)\s+(?:strikes?|hits?|bombs?|attacks?|targets?|launch(?:es)?)\b|\b(struck|hit|hits|bombed|launch(?:es|ed)?|carr(?:y|ies|ied) out|conduct(?:s|ed)?|killed|injured|wounded|exploded|attacked|targeted|destroyed|damaged|shot down|intercepted|confirm(?:s|ed)?|rocked|heard|reported|reports?|witnesses?|residents?|landed|slammed)\b|حمله کرد|حمله کردند|بمباران کرد|موشک.?باران کرد|هدف قرار دادند|حمله شد|انجام شد|انجام داد|شنیده شد|گزارش شد|اصابت کرد|هدف قرار گرف|هدف قرار داد|منفجر شد|بمباران شد|کشته شد|مجروح شد|تأیید کرد|تایید کرد|رخ داد|روی داد|صدای انفجار|شاهدان|ساکنان|شنیده شده|اصابت/;

const HIST = new RegExp([
  'anniversary', 'last (?:year|month|week)', 'years? ago', 'in (?:19|20)\\d\\d', 'history', 'remember', 'commemorat',
  'سالگرد', 'سال گذشته', 'پارسال', 'ماه گذشته', 'هفته گذشته', 'سال‌ها پیش', 'تاریخ', 'یادبود'
].join('|'));

const UNCERTAIN = new RegExp([
  'denied', 'denies', 'rumou?rs?', 'fake', 'false', 'no reports of', 'hoax', 'unfounded', 'debunk',
  'تکذیب', 'شایعه', 'جعلی', 'کذب', 'خبری از .{0,20} نیست', 'ساختگی', 'ادعای'
].join('|'));

const FRESH = /(today|just now|hours? ago|minutes? ago|breaking|moments ago|امروز|ساعاتی پیش|همین الان|لحظاتی پیش|دقایقی پیش|فوری)/;

// «تهران» به‌عنوان دولت (Tehran warns / تهران هشدار داد) شهر نیست
const METONYM_EN = /\b(tehran|iran(?:'s)? (?:government|regime|leaders?))\s+(warns?|says?|said|denies|denied|rejects?|rejected|insists?|claims?|vows?|responds?|retaliates?|threatens?|urges?|accuses?|has|will|is|announces?|announced|confirms? (?:it|that)|blames?)\b/g;
const METONYM_FA = /(تهران|دولت ایران|ایران)\s+(هشدار|اعلام|تکذیب|گفت|می.?گوید|رد کرد|پاسخ|واکنش)/g;

// جدا کردن بخش‌های تیتر؛ «و» و ویرگول جدا نمی‌کنند تا فهرست شهرها یک‌پارچه بماند
const CLAUSE_SPLIT = /\s*(?:;|؛|—|–|\s-\s|:|\s(?:as|while|amid|after|but|despite|though|although|whereas|before|following)\s|\sدر حالی ?که\s|\sدرحالی‌که\s|\sپس از\s|\sاما\s|\sولی\s)\s*/i;

const NOT_NEWS_PREFIX = /^\s*(?:scenario|analysis|opinion|explainer|editorial|commentary|fiction|simulation|drill|exercise|what if|سناریو|تحلیل|یادداشت|مانور|رزمایش|فرضی)\s*[:：\-—]/i;
function sentences(text) {
  return String(text || '').split(/(?<=[.!?؟۔\n])\s+|\n+/).map(s => s.trim()).filter(Boolean);
}
function clausesOf(raw) { return String(raw || '').split(CLAUSE_SPLIT).map(x => x.trim()).filter(Boolean); }
function cleanNorm(raw) { return norm(raw).replace(METONYM_EN, ' ').replace(METONYM_FA, ' '); }
function citiesIn(n) {
  const out = [];
  for (const p of PROVINCES) for (const [id, , re] of p.places) if (re.test(n)) out.push(id);
  if (GENERIC_IRAN.test(n)) out.push('Iran');
  return out;
}
function isHypothetical(raw) { const n = norm(raw); return HYPO.test(n); }
// برای نشانگرها فقط جمله‌های واقعاً شرطی کم‌اثر می‌شوند («هشدار داد» و «تهدید» خبر واقعی‌اند)
const COND = /\bif\b|\bcould\b|\bwould\b|\bmight\b|what happens|what if|scenario|hypothetical|simulat|\bdrills?\b|\bexercises?\b|اگر|در صورت|چنانچه|سناریو|مانور|رزمایش|چه می.?شود|شبیه.?سازی/;
function isConditional(raw) { return COND.test(norm(raw)); }
// نشانه نظامی واقعی (موشک، پهپاد، حمله هوایی...) و علت‌های غیرنظامی (گاز، آتش‌سوزی، آتش‌بازی...)
const VECTOR = /air ?strikes?|airstrike|missiles?|rockets?|drones?|bomb(ed|ing|s|ers?)?\b|bombard\w*|shelling|shelled|warplanes?|fighter jets?|jets? (struck|hit)|strikes? (on|against|hit|hits|rocked)|\bstruck\b|\bstrikes?\b|حمله هوایی|بمباران|موشک|پهپاد|جنگنده|حمله (به|علیه)|اصابت/;
const HOSTILE = /\bisrael(i)?\b|american|\bus (forces|military|jets|strikes?)\b|u\.s\. (forces|military)|enemy|zionist|اسرائیل|آمریکا|دشمن|صهیونیست/;
const ACCIDENT = /gas (leak|explosion|cylinder|tank|station)|cooking gas|propane|fireworks?|sonic boom|short.?circuit|\bboiler\b|(factory|industrial|workshop|warehouse) (fire|explosion|blast)|building collapse|pipeline (leak|fire|blast)|(mine|mining) (collapse|explosion|blast)|\baccident\b|\bcrash(ed)?\b|گاز|کپسول|نشت|آتش.?بازی|بوم صوتی|اتصال برق|دیگ بخار|حادثه|معدن|فروریخت|ریزش|آتش.?سوزی|کارگاه|کارخانه/;
const WIDE = /waves? of|\bwave\b|widespread|multiple (cities|sites|provinces|targets|locations)|several (cities|provinces|sites)|across (the )?(country|iran)|dozens of|large.?scale|massive|nationwide|launch(ed|es|ing)? (a |an )?[a-z ,-]{0,30}(strikes?|attack|offensive|operation|campaign)|began (strikes|bombing|an offensive)|گسترده|موج|چند(ین)? شهر|سراسر|ده‌ها|تمام کشور|صدها|آغاز حمله|شروع حمله|عملیات/;

/* آیا این بخش از متن، «رویداد حمله نظامی به مکانی در ایران» را می‌گوید؟  ctx = کل جمله برای فعل رویداد و نشانه نظامی */
function attackClause(clause, ctx) {
  const n = cleanNorm(clause), c = cleanNorm(ctx || clause);
  if (!ATTACK.test(n)) return null;
  if (HYPO.test(n) || NEG.test(n) || INTENT.test(n) || HIST.test(n) || UNCERTAIN.test(n)) return null;
  const v = VECTOR.test(c);
  if (ACCIDENT.test(c) && !v) return null;               // انفجار گاز، آتش‌سوزی، آتش‌بازی...
  if (!v && !HOSTILE.test(c)) return null;               // «انفجار» بدون هیچ نشانه حمله نظامی
  if (!EVENT.test(c)) return null;                        // باید «رخداد» باشد، نه گفتار یا بحث
  const places = citiesIn(n);
  return places.length ? { places, text: n } : null;
}
// extra = متن اطراف (توضیح یا کل مقاله) که فقط برای نشانه نظامی و فعل رویداد به‌کار می‌رود؛ خودِ بخش حمله باید بدون نفی و برنامه باشد
function attackHits(text, extra) {
  const hits = [];
  const more = String(extra || '').slice(0, 3000);
  for (const s of sentences(text)) {
    if (NOT_NEWS_PREFIX.test(norm(s))) continue;      // «سناریو: …»، «تحلیل: …»، «Opinion: …» خبر رویداد نیستند
    for (const cl of clausesOf(s)) { const h = attackClause(cl, s + ' ' + more); if (h) hits.push(h); }
  }
  return hits;
}
function qualifies(raw) { const h = attackHits(raw); return h.length ? uniq(h.reduce((a, x) => a.concat(x.places), [])) : null; }
function looksLikeAttack(item) {
  const n = cleanNorm(item.title + ' ' + (item.body || '').slice(0, 400));
  return ATTACK.test(n) && citiesIn(n).length > 0;
}
// دلیل رد شدن، برای نمایش به کاربر
function explainReject(title) {
  const n = cleanNorm(title);
  if (UNCERTAIN.test(n)) return 'تیتر تکذیب، شایعه یا «ادعا» است';
  if (HIST.test(n)) return 'درباره رویداد گذشته است';
  const parts = clausesOf(title).map(cleanNorm).filter(x => ATTACK.test(x));
  if (parts.some(x => NEG.test(x))) return 'انکار یا نفی حمله است (مثلاً «برنامه‌ای برای حمله ندارد»)';
  if (parts.some(x => INTENT.test(x) || HYPO.test(x))) return 'درباره برنامه، تهدید یا احتمال است، نه رویداد واقعی';
  if (!EVENT.test(n)) return 'خبر رخداد نیست (فعل رویداد مثل «اصابت کرد / شنیده شد» ندارد)';
  return 'نشانه روشن حمله نظامی در شهر ایران دیده نشد';
}

/* تأیید یک خبر: آیا واقعاً خبر رخداد حمله نظامی در ایران است؟ و در چه مقیاسی؟ */
function verifyAttack(item, now) {
  now = now || Date.now();
  if (matchesIgnore(item.title)) return { ok: false, reason: 'نادیده گرفته شد (طبق قانون خودتان)' };
  const tn = norm(item.title);
  const age = item.ts ? now - item.ts : 0;
  if (age > 6 * HOUR) return { ok: false, reason: 'خبر قدیمی است' };

  const full = norm(item.title + ' . ' + (item.body || ''));
  if (ACCIDENT.test(full) && !VECTOR.test(full)) return { ok: false, reason: 'حادثه غیرنظامی است (گاز، آتش‌سوزی، آتش‌بازی...)، نه حمله' };
  if (ATTACK.test(tn) && !VECTOR.test(full) && !HOSTILE.test(full)) return { ok: false, reason: 'انفجار گزارش شده، اما هیچ نشانه‌ای از حمله نظامی نیست' };

  const tHits = attackHits(item.title, item.body || '');
  const bHits = item.fullText ? attackHits(item.body || '', item.body || '') : [];
  if (!tHits.length && !(item.fullText && bHits.length)) return { ok: false, reason: explainReject(item.title) };
  if (!tHits.length) {
    // عنوان رویداد را نمی‌گوید؛ فقط اگر عنوان تکذیب/نفی نباشد و متن رویداد را روشن بگوید می‌پذیریم
    if (NEG.test(cleanNorm(item.title)) || UNCERTAIN.test(tn)) return { ok: false, reason: explainReject(item.title) };
  }
  let res;
  const placesOf = hs => uniq(hs.reduce((a, x) => a.concat(x.places), []));
  if (item.fullText) {
    if (!bHits.length) {
      // متن، رخداد را با نام شهر تکرار نکرده؛ اگر عنوان رخداد را روشن می‌گوید می‌پذیریم، ولی فقط در سطح «خلاصه» (برای آماده‌باش حمله و آلارم کامل کافی نیست)
      if (!tHits.length) return { ok: false, reason: 'متن کامل رخداد حمله نظامی در شهر ایران را تأیید نکرد' };
      res = { ok: true, textLevel: 'summary', cities: placesOf(tHits), _txt: tHits.map(h => h.text).join(' . ') };
    } else {
      if (!(tHits.length || FRESH.test(full) || (item.ts && age <= 3 * HOUR))) return { ok: false, reason: 'نشانه تازه بودن خبر دیده نشد' };
      const hits = tHits.concat(bHits);
      res = { ok: true, textLevel: 'full', cities: placesOf(hits), _txt: hits.map(h => h.text).join(' . ') };
    }
  } else {
    res = { ok: true, textLevel: 'summary', cities: placesOf(tHits), _txt: tHits.map(h => h.text).join(' . ') };
  }
  const named = res.cities.filter(c => c !== 'Iran');
  res.scale = (named.length >= 2 || WIDE.test(res._txt)) ? 'wide' : 'limited';   // مقیاس فقط از جمله‌های حمله سنجیده می‌شود
  delete res._txt;
  res.provinces = uniq(named.map(provinceOf).filter(Boolean));
  return res;
}
function uniq(a) { return Array.from(new Set(a)); }
function overlap(a, b) {
  if (a.includes('Iran') || b.includes('Iran')) return true;
  return a.some(x => b.includes(x));
}

/* خانواده منبع: خبرگزاری‌های دولتی ایران (ایرنا، ایسنا، مهر، تسنیم، فارس...) معمولاً یک خبر را بازنشر می‌کنند؛ یک منبع حساب می‌شوند */
function family(g) { return IR_SOURCE.test(String(g || '')) ? 'iran-state' : String(g || ''); }

/* وضعیت آلارم از روی خبرهای تأییدشده.
   capital  = حمله به استان‌های حساس (پیش‌فرض تهران و البرز)؛ دو منبع مستقل (دست‌کم یکی غیرایرانی)
   full     = دو منبع مستقل (دست‌کم یکی غیرایرانی) + حمله گسترده
   standby  = یک منبع غیرایرانی با متن کامل، حمله گسترده
   incident = رویداد محدود یا فقط منبع ایرانی: اعلان بی‌صدا، نه آلارم */
function alertState(verified, now, watch) {
  now = now || Date.now();
  watch = watch || DEFAULT_WATCH;
  const recent = verified.filter(v => now - (v.ts || now) <= 120 * MIN);
  if (!recent.length) return { level: 'none' };
  const hot = v => (v.provinces || []).some(p => watch.includes(p));
  const pair = (pred) => {
    for (const a of recent) for (const b of recent) {
      if (a === b) continue;
      const fa = family(a.group), fb = family(b.group);
      if (fa === fb) continue;
      if (fa === 'iran-state' && fb === 'iran-state') continue;
      if (fa === 'iran-state' && fb === 'iran-state') continue;
      if (fa === 'iran-state' || fb === 'iran-state') { /* یکی ایرانی، دیگری خارجی: مجاز */ }
      if (!overlap(a.cities, b.cities)) continue;
      if (Math.abs((a.ts || now) - (b.ts || now)) > 90 * MIN) continue;
      // دو منبع غیرایرانی مستقل که هر دو در «تیتر» رخداد را روشن گفته‌اند کافی است (متن بسیاری از رسانه‌ها از راه گوگل خوانده نمی‌شود)؛ وگرنه دست‌کم یکی باید با متن کامل تأیید شده باشد
      if (a.textLevel !== 'full' && b.textLevel !== 'full' && (fa === 'iran-state' || fb === 'iran-state')) continue;
      if (pred && !pred(a, b)) continue;
      return [a, b];
    }
    return null;
  };
  const placeCities = w => uniq(w[0].cities.concat(w[1].cities)).filter(c => c !== 'Iran');
  const hotPair = pair((a, b) => hot(a) && hot(b) && placeCities([a, b]).some(c => watch.includes(provinceOf(c))));
  if (hotPair) { const cities = placeCities(hotPair); return { level: 'capital', key: 'capital:' + (cities[0] || 'Iran') + ':' + Math.floor(Math.min(hotPair[0].ts || now, hotPair[1].ts || now) / HOUR), cities, items: hotPair }; }
  const w = pair((a, b) => a.scale === 'wide' || b.scale === 'wide' || (a.cities.includes('Tehran') && b.cities.includes('Tehran')));
  if (w) {
    const cities = placeCities(w);
    return { level: 'full', key: 'full:' + (cities[0] || 'Iran') + ':' + Math.floor(Math.min(w[0].ts || now, w[1].ts || now) / HOUR), cities, items: w };
  }
  const solo = recent.filter(v => v.textLevel === 'full' && v.scale === 'wide' && family(v.group) !== 'iran-state');
  if (solo.length) {
    const a = solo[0], cities = a.cities.filter(c => c !== 'Iran');
    return { level: 'standby', key: 'standby:' + (cities[0] || 'Iran') + ':' + Math.floor((a.ts || now) / HOUR), cities, items: [a] };
  }
  const lim = pair(null) || (recent.find(v => v.textLevel === 'full') ? [recent.find(v => v.textLevel === 'full')] : null) || [recent[0]];
  const cities = uniq(lim.reduce((x, i) => x.concat(i.cities), [])).filter(c => c !== 'Iran');
  return { level: 'incident', key: 'incident:' + (cities[0] || 'Iran') + ':' + Math.floor((lim[0].ts || now) / HOUR), cities, items: lim };
}

/* ---------- قانون‌های نشانگرها (بر اساس تحلیل جنگ‌های ژوئن ۲۰۲۵، ژانویه و فوریه ۲۰۲۶) ----------
   tier: A = بسیار قوی (ساعت‌ها تا یک روز زودتر)، B = قوی (چند روز)، C = زمینه‌ای (هفته‌ها)
   ease = نشانه کاهش تنش | N = خبر عمومی تنش */
const RULES = [
  // ---- رده A ----
  { id:'r01', ind:'embassy',  tier:'A', pts:+12, label:'دستور خروج کارکنان سفارت (یا «همین امروز خارج شوید»)',
    all:[/embass|consulate|state department|سفارت|کنسولگری|وزارت خارجه/, /ordered departure|non-emergency|leave[^.]{0,30}today|should do so today|authorized departure|همین امروز|خروج کارکنان غیرضروری|دستور خروج/] },
  { id:'r02', ind:'airspace', tier:'A', pts:+10, label:'اعلان رسمی (NOTAM) بسته شدن آسمان خود ایران',
    all:[/(iran(ian)?|tehran)'?s? (airspace|fir)|airspace (of|over|in) (iran|tehran)|iran(ian)? (authorities |civil aviation )?(clos|shut)\w* (its |the )?(national |entire )?airspace|notam[^.]{0,40}(iran|tehran)|(iran|tehran)[^.]{0,40}notam|حریم هوایی ایران|آسمان ایران|نوتم/, /\bclos(e|es|ed|ing|ure)\b|shut|bann|بسته|مسدود|ممنوع/], none:[/reopen|re-open|resum|باز شد|بازگش|از سر گرفت/] },
  // ---- رده B ----
  { id:'r03', ind:'embassy',  tier:'B', pts:+8,  label:'کاهش کارکنان سفارت‌ها یا تسریع تخلیه دیپلمات‌ها',
    all:[/embass|diplomat|سفارت|دیپلمات/, /draw ?down|reduc[^.]{0,20}(staff|personnel)|accelerat[^.]{0,25}(evacuat|departure)|کاهش (کارکنان|نیرو)|تسریع.{0,15}تخلیه/] },
  { id:'r04', ind:'embassy',  tier:'B', pts:+10, label:'تعطیلی یا تخلیه سفارت',
    all:[/embass|consulate|سفارت|کنسولگری/, /\bclos(e|es|ed|ing|ure)\b|evacuat|withdraw|suspend|تعطیل|تخلیه|بسته/], none:[/reopen|re-open|باز شد|بازگشایی/, /protest|demand|call(s|ed)? for|rall(y|ies)|march|تجمع|تظاهرات|اعتراض|خواستار|مطالبه/] },
  { id:'r05', ind:'embassy',  tier:'B', pts:+8,  label:'هشدار «ایران را ترک کنید» یا هشدار سفر سطح ۴',
    all:[/do not travel|leave (iran|the country)|level 4|urges citizens|ترک ایران|هشدار سفر|فراخوان.{0,10}اتباع/, /iran|ایران|iraq|عراق|israel|اسرائیل|region|منطقه/] },
  { id:'r06', ind:'airspace', tier:'B', pts:+7,  label:'بسته شدن یا محدود شدن آسمان منطقه',
    all:[/airspace|حریم هوایی|آسمان/, /\bclos(e|es|ed|ing|ure)\b|shut|restrict|بسته|مسدود|محدود/], none:[/reopen|re-open|resum|باز شد|بازگش|از سر گرفت/] },
  { id:'r07', ind:'airspace', tier:'B', pts:+6,  label:'لغو یا تعلیق پروازها',
    all:[/flights?|airlines?|پرواز|ایرلاین/, /cancel|suspend|halt|divert|لغو|تعلیق|متوقف|تغییر مسیر/], none:[/resum|از سر گرفت/] },
  { id:'r08', ind:'military', tier:'B', pts:+8,  label:'تخلیه اتباع یا کارشناسان روسیه یا چین از ایران',
    all:[/russia|rosatom|chinese|china|روس|چین/, /evacuat|withdraw|pull(ed)? out|تخلیه|خارج کرد|خروج/, /iran|bushehr|ایران|بوشهر/] },
  { id:'r09', ind:'military', tier:'B', pts:+6,  label:'تغییر وضعیت نیروهای آمریکایی در پایگاه‌های منطقه',
    all:[/al.?udeid|العدید|us (bases|forces|troops)|پایگاه/, /leave|relocat|move out|posture|evacuat|خروج|جابجایی|تخلیه/] },
  { id:'r10', ind:'news',     tier:'B', pts:+6,  label:'ضرب‌الاجل رسمی یا شکست مذاکرات',
    all:[/deadline|ultimatum|talks (collapse|fail|break)|negotiations (collapse|fail)|ضرب.?الاجل|مهلت|شکست مذاکرات/, /iran|ایران/], none:[/midterm|election|primary|budget|shutdown|debt ceiling|انتخابات|میان.?دوره/] },
  // ---- رده C ----
  { id:'r11', ind:'military', tier:'C', pts:+6,  label:'اعزام ناو یا بمب‌افکن',
    all:[/aircraft carrier|carrier strike|warships?|bombers?|ناو|ناوگروه|بمب.?افکن/, /deploy|\bsen[dt]s?\b|sending|moves?|dispatch|head(s|ed|ing)? to|اعزام|مستقر|حرکت/] },
  { id:'r12', ind:'military', tier:'C', pts:+5,  label:'جلسه امنیتی یا شورای امنیت درباره ایران',
    all:[/security council|security cabinet|شورای امنیت|کابینه امنیتی/, /emergency|urgent|iran|اضطراری|فوری|ایران/] },
  { id:'r13', ind:'military', tier:'C', pts:+6,  label:'آماده‌باش نظامی یا رزمایش تهاجمی نزدیک ایران',
    all:[/high alert|on alert|mobiliz|simulated (attack|strike)|آماده.?باش|بسیج نیرو/] },
  { id:'r14', ind:'news',     tier:'C', pts:+4,  label:'گزارش آژانس اتمی یا تصمیم علیه برنامه هسته‌ای',
    all:[/iaea|آژانس (بین.?المللی )?انرژی اتمی|آژانس اتمی/, /report|resolution|board|گزارش|قطعنامه/] },
  // ---- نشانه‌های تازه ----
  { id:'r15', ind:'military', tier:'B', pts:+7, label:'هشدار مقام‌ها: حمله «قریب‌الوقوع» یا طرح حمله آماده',
    all:[/imminent|within (hours|days)|preparing (for )?(a )?(strike|attack)|planning (a )?(strike|attack)|approved (a )?strike|strike plans?|قریب.?الوقوع|طرح حمله/, /iran|ایران/] },
  { id:'r16', ind:'military', tier:'B', pts:+7, label:'تغییر دستورالعمل دفاع غیرنظامی اسرائیل (Home Front Command)',
    all:[/home front command|فرماندهی جبهه داخلی/, /restrict|guideline|shelter|gathering|school|cancel|پناهگاه|محدودیت|تجمع|مدارس/] },
  { id:'r17', ind:'airspace', tier:'B', pts:+8, label:'بسته شدن آسمان اسرائیل یا فرودگاه بن‌گوریون',
    all:[/israel(i)?|ben gurion|اسرائیل|بن گوریون/, /airspace|airport|حریم هوایی|فرودگاه/, /\bclos(e|es|ed|ing|ure)\b|shut|بسته|مسدود/], none:[/reopen|re-open|resum|باز شد|بازگش|از سر گرفت/] },
  { id:'r18', ind:'airspace', tier:'B', pts:+7, label:'بسته شدن آسمان کشورهای خلیج فارس',
    all:[/qatar|uae|emirates|bahrain|kuwait|saudi|oman|iraq|jordan|قطر|امارات|بحرین|کویت|عربستان|عمان|عراق|اردن/, /airspace|حریم هوایی/, /\bclos(e|es|ed|ing|ure)\b|shut|bann|بسته|مسدود/], none:[/reopen|re-open|resum|باز شد|بازگش|از سر گرفت/] },
  { id:'r19', ind:'military', tier:'B', pts:+6, label:'استقرار سوخت‌رسان، بمب‌افکن یا پدافند آمریکا نزدیک ایران',
    all:[/tanker aircraft|kc-135|kc-46|b-2|b-52|f-22|f-35|thaad|patriot|air defen[cs]e|سوخت.?رسان|پدافند/, /deploy|sent|moves?|dispatch|arriv|اعزام|مستقر|رسید/] },
  { id:'r20', ind:'markets',  tier:'B', pts:+6, label:'تنگه هرمز: حمله به کشتی، مین‌گذاری یا هشدار دریایی (UKMTO/JMIC)',
    all:[/hormuz|هرمز|ukmto|jmic|tanker|نفتکش|شناور|کشتی.{0,12}(تجاری|نفتکش|باری)|(تجاری|باری).{0,5}کشتی/, /attack|mine|seiz|\bclos(e|es|ed|ing|ure)\b|advisory|threat|حمله|مین|توقیف|بسته|هشدار/] },
  { id:'r21', ind:'markets',  tier:'C', pts:+4, label:'افزایش حق‌بیمه جنگ برای کشتی‌های خلیج فارس',
    all:[/war.?risk|insurers?|insurance|حق.?بیمه|بیمه/, /gulf|hormuz|iran|خلیج|هرمز|ایران/, /rise|raise|hike|surge|jump|suspend|cancel|افزایش|لغو/] },
  { id:'r22', ind:'markets',  tier:'C', pts:+4, label:'جهش ناگهانی صادرات یا بارگیری نفت ایران',
    all:[/iran(ian)?|kharg|ایران|خارک/, /oil exports?|crude exports?|tanker loading|loading|صادرات نفت|بارگیری/, /surge|jump|rise|accelerat|record|افزایش|جهش|شتاب/] },
  // ---- پدافند غیرعامل، فضای سایبری و وضعیت داخلی (تعطیلی‌ها اغلب بخاطر آلودگی یا برق است؛ فقط با زمینه امنیتی حساب می‌شود) ----
  { id:'r23', ind:'civil', tier:'A', pts:+10, label:'تعطیلی مدارس و دانشگاه‌ها تا اطلاع ثانوی همراه با اعلام وضعیت امنیتی',
    all:[/school|universit|مدرسه|دانشگاه/, /until further notice|تا اطلاع ثانوی/, /security council|supreme national security|attack|strike|war\b|شورای عالی امنیت|حمله|جنگ/],
    none:[/pollution|smog|sandstorm|dust|energy|electric|power|cold|snow|آلودگی|گرد.?و.?غبار|برق|انرژی|سرما|برف/] },
  { id:'r24', ind:'civil', tier:'A', pts:+10, label:'توقف معاملات بورس تهران همزمان با حمله',
    all:[/stock exchange|tse\b|بورس/, /halt|suspend|توقف|تعلیق|تعطیل/, /strike|attack|explosion|war\b|حمله|انفجار|جنگ/] },
  { id:'r25', ind:'civil', tier:'B', pts:+8, label:'قطع شبکه تلفن همراه در تهران یا سراسر ایران',
    all:[/mobile|cellular|phone services|تلفن همراه|موبایل/, /\bcut\b|\bdown\b|suspend|shut|blackout|قطع|اختلال سراسری/, /tehran|iran|تهران|ایران/], none:[/test|maintenance|power outage|تعمیر|قطع برق/] },
  { id:'r26', ind:'civil', tier:'B', pts:+6, label:'قطع یا اختلال سراسری اینترنت ایران (NetBlocks)',
    all:[/netblocks|internet (shutdown|blackout|outage|disruption)|قطع (سراسری )?اینترنت/, /iran|ایران/] },
  { id:'r27', ind:'civil', tier:'B', pts:+6, label:'رهبران یا فرماندهان ایرانی به پناهگاه منتقل شدند',
    all:[/supreme leader|khamenei|irgc commanders|رهبر انقلاب|فرماندهان سپاه/, /bunker|hiding|relocat|moved to|پناهگاه|مخفی|جابجا/] },
  { id:'r28', ind:'civil', tier:'C', pts:+4, label:'اطلاعیه پدافند غیرعامل یا مدیریت بحران (پناهگاه، آژیر، وضعیت قرمز)',
    all:[/passive defen[cs]e|civil defen[cs]e|crisis management|پدافند غیرعامل|مدیریت بحران/, /alert|warning|red|shelter|siren|آماده.?باش|هشدار|پناهگاه|آژیر|وضعیت قرمز/] },
  { id:'r29', ind:'civil', tier:'C', pts:+4, label:'حمله سایبری به بانک، سوخت، بندر یا صداوسیمای ایران',
    all:[/cyber ?attack|hack(ed|ers?)?|حمله سایبری|هک/, /bank|fuel|gas station|state tv|broadcast|port|metro|بانک|جایگاه|صدا و سیما|بندر|مترو/, /iran|ایران/] },
  { id:'r30', ind:'civil', tier:'C', pts:+3, label:'خرید هیجانی یا صف‌های غیرعادی (بنزین، خودپرداز، مواد غذایی)',
    all:[/panic buying|long queues|hoarding|هجوم برای خرید|صف.{0,12}(بنزین|خودپرداز|نان)|احتکار/, /iran|ایران|tehran|تهران/] },
  { id:'r31', ind:'civil', tier:'C', pts:+3, label:'فراخوان اهدای خون یا آماده‌باش بیمارستان‌ها',
    all:[/blood donation|hospitals? (on|placed on|put on) alert|اهدای خون|آماده.?باش بیمارستان/, /iran|ایران/] },
  { id:'r32', ind:'airspace', tier:'C', pts:+3, label:'اختلال یا جعل GPS در ایران و خلیج فارس',
    all:[/gps (jamming|spoofing|interference)|اختلال (در )?جی.?پی.?اس/, /iran|gulf|persian|ایران|خلیج/] },
  // ---- کاهش تنش ----
  { id:'r33', ind:'airspace', tier:'ease', pts:-9, label:'بازگشایی آسمان یا از سرگیری پرواز',
    all:[/airspace|حریم هوایی|flights?|پرواز/, /reopen|re-open|resum|باز شد|بازگشایی|از سر گرفت|از ?سر ?گیری/] },
  { id:'r34', ind:'embassy',  tier:'ease', pts:-8, label:'بازگشایی سفارت یا کاهش هشدار سفر',
    all:[/embass|consulate|travel advisory|سفارت|هشدار سفر/, /\breopen(s|ed|ing)?\b|re-open|\blowers?\b|\blowered\b|\beased\b|\blifted\b|باز شد|بازگشایی|لغو شد/] },
  { id:'r35', ind:'news',     tier:'ease', pts:-4, label:'خبر کاهش تنش (آتش‌بس، مذاکره)',
    all:[/ceasefire|truce|de-escalat|negotiat|talks|آتش.?بس|مذاکره|کاهش تنش|توافق/] },
];
const BASE_RULES = RULES;

const IRAN_REL = /iran|ایران|tehran|تهران|bushehr|بوشهر|hormuz|هرمز|persian gulf|خلیج فارس/;
function isIranianSource(item) { return IR_SOURCE.test(String(item.source || '') + ' ' + String(item.group || '')); }


/* ---------- پیکربندی قابل تغییر از داخل اپ (بدون ساخت دوباره) ----------
   pack = «بسته قانون» (JSON) که Claude می‌دهد؛  user = تنظیمات خود کاربر در اپ */
let CFG = { pack: null, user: {} };
let EFF = null;
function compilePattern(src) {
  if (src instanceof RegExp) return src;
  const t = String(src);
  if (t.length > 500) throw new Error('الگو خیلی طولانی است');
  return new RegExp(t, 'i');
}
function toIgnoreRe(p) {
  const t = String(p || '').trim();
  if (!t) return null;
  try {
    if (t.startsWith('/') && t.lastIndexOf('/') > 0) { const i = t.lastIndexOf('/'); return new RegExp(t.slice(1, i), t.slice(i + 1) || 'i'); }
    return new RegExp(t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
  } catch (e) { return null; }
}
function buildEffective() {
  const pack = CFG.pack || {}, user = CFG.user || {};
  const off = new Set((pack.disableRules || []).concat(Object.keys(user.ruleOff || {}).filter(k => user.ruleOff[k])));
  const rules = [];
  for (const r of BASE_RULES) {
    if (off.has(r.id)) continue;
    let pts = r.pts;
    const pe = pack.ruleEdits && pack.ruleEdits[r.id];
    if (pe && pe.pts != null) pts = +pe.pts;
    const up = user.rulePts && user.rulePts[r.id];
    if (up != null && up !== '' && !isNaN(+up)) pts = +up;
    rules.push(Object.assign({}, r, { pts }));
  }
  for (const r of (pack.rules || [])) {
    if (off.has(r.id)) continue;
    try { rules.push({ id: r.id || ('p' + rules.length), ind: r.ind, tier: r.tier || 'C', pts: +r.pts, label: r.label || r.id, all: (r.all || []).map(compilePattern), none: (r.none || []).map(compilePattern), custom: true }); } catch (e) { /* قانون خراب نادیده گرفته می‌شود */ }
  }
  const ign = (pack.ignorePhrases || []).concat(user.ignore || []).map(toIgnoreRe).filter(Boolean);
  const rm = new Set((pack.sources && pack.sources.remove) || []);
  const sources = SOURCES.filter(x => !rm.has(x.id)).concat(((pack.sources && pack.sources.add) || []).filter(x => x && x.id && x.url));
  const watch = (user.watch && user.watch.length) ? user.watch : DEFAULT_WATCH;
  return { rules, ign, weights: Object.assign({}, pack.weights || {}), sources, watch };
}
function configure(cfg) { CFG = { pack: (cfg && cfg.pack) || null, user: (cfg && cfg.user) || {} }; EFF = buildEffective(); }
function effCfg() { if (!EFF) EFF = buildEffective(); return EFF; }
function getConfig() { return { pack: CFG.pack, user: CFG.user }; }
function getSources() { return effCfg().sources; }
function getWatch() { return effCfg().watch; }
function matchesIgnore(title) { const t = norm(title); return effCfg().ign.some(re => re.test(t) || re.test(String(title))); }
function rulesCatalog() { return BASE_RULES.map(r => ({ id: r.id, ind: r.ind, tier: r.tier, pts: r.pts, label: r.label })); }
function validatePack(pack) {
  const errors = [];
  if (!pack || typeof pack !== 'object') return { ok: false, errors: ['بسته قانون باید یک شیء JSON باشد'] };
  if (JSON.stringify(pack).length > 120000) errors.push('بسته خیلی بزرگ است');
  if (pack.version != null && !(Number.isInteger(+pack.version) && +pack.version >= 0)) errors.push('version باید عدد صحیح باشد');
  const ids = new Set(INDICATORS.map(i => i.id));
  (pack.rules || []).forEach((r, i) => {
    const tag = 'rules[' + i + ']' + (r && r.id ? ' (' + r.id + ')' : '');
    if (!r || !r.id) errors.push(tag + ': id لازم است');
    else if (!ids.has(r.ind)) errors.push(tag + ': ind نامعتبر است');
    else if (isNaN(+r.pts) || Math.abs(+r.pts) > 30) errors.push(tag + ': pts باید بین ۳۰- و ۳۰ باشد');
    else if (!['A', 'B', 'C', 'ease'].includes(r.tier || 'C')) errors.push(tag + ': tier باید A,B,C یا ease باشد');
    else if (!Array.isArray(r.all) || !r.all.length) errors.push(tag + ': all باید فهرست الگو باشد');
    else { try { (r.all || []).concat(r.none || []).forEach(compilePattern); } catch (e) { errors.push(tag + ': الگو خراب است (' + e.message + ')'); } }
  });
  (pack.ignorePhrases || []).forEach((x, i) => { if (!toIgnoreRe(x)) errors.push('ignorePhrases[' + i + '] خراب است'); });
  ((pack.sources && pack.sources.add) || []).forEach((x, i) => { if (!x || !x.id || !/^https?:\/\//.test(x.url || '')) errors.push('sources.add[' + i + ']: id و url لازم است'); });
  return { ok: errors.length === 0, errors };
}

function classify(item, now) {
  now = now || Date.now();
  const ts = item.ts || now;
  const nBody = norm(item.title + ' . ' + (item.body || '').slice(0, 300));
  if (!IRAN_REL.test(nBody)) return [];            // خبر باید خودش درباره ایران باشد
  if (matchesIgnore(item.title)) return [];        // قانون «نادیده بگیر» خود کاربر
  // قانون‌ها فقط روی تیتر اجرا می‌شوند؛ اگر ایران فقط در توضیح خبر آمده، یک نشانه «iran» اضافه می‌شود
  const n = norm(item.title) + (IRAN_REL.test(norm(item.title)) ? '' : ' iran');
  const cond = isConditional(item.title);
  const ir = isIranianSource(item);
  const out = [];
  const used = new Set();
  for (const r of effCfg().rules) {
    if (!r.all.every(re => re.test(n))) continue;
    if (r.none && r.none.some(re => re.test(n))) continue;
    if (ir && r.pts < 0) continue;             // «کاهش تنش» از منابع ایرانی حساب نمی‌شود
    const k = r.ind + (r.pts > 0 ? '+' : '-');
    if (used.has(k)) continue;
    used.add(k);
    let pts = r.pts;
    if (pts > 0 && cond) pts *= 0.4;
    if (pts > 0 && ir) pts *= 0.5;
    out.push({
      id: (item.link || item.title) + '|' + r.label,
      ind: r.ind, tier: r.tier, label: r.label, rid: r.id, hypo: cond, ir, pts,
      title: item.title, source: item.source, group: item.group, ts, link: item.link,
    });
  }
  return out;
}

/* آماده‌باش خانواده: یک نشانه رده A، یا دو نشانه متفاوت رده B از دو منبع مستقل در ۲۴ ساعت */
function readinessState(events, now) {
  now = now || Date.now();
  const recent = events.filter(e => e.pts > 0 && !e.hypo && !e.ir && now - e.ts <= 24 * HOUR && (e.tier === 'A' || e.tier === 'B'));
  const a = recent.filter(e => e.tier === 'A');
  const b = recent.filter(e => e.tier === 'B');
  const labels = uniq(a.concat(b).map(e => e.label)).sort();
  // کلید فقط به «نوع شواهد» بستگی دارد؛ تکرار همان خبر یا گذشتن زمان، آلارم تازه نمی‌سازد
  const key = 'ready:' + labels.join('|');
  if (a.length) return { level: 'ready', key, why: 'نشانه رده A: ' + a[0].label, items: a.concat(b).slice(0, 5) };
  const groups = uniq(b.map(e => e.group));
  if (uniq(b.map(e => e.label)).length >= 2 && groups.length >= 2) return { level: 'ready', key, why: 'دو نشانه رده B از منابع مستقل', items: b.slice(0, 5) };
  return { level: 'none' };
}

/* ترافیک هوایی: دو مقایسه، ۱) با ۳ ساعت اخیر (افت ناگهانی)  ۲) با همین ساعت روزهای قبل
   cur = { n: تعداد کل منطقه, i: تعداد بالای ایران } */
function median(a) { const b = a.slice().sort((x, y) => x - y); const m = b.length >> 1; return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2; }
function flightRisk(samples, cur, now) {
  now = now || Date.now();
  if (!cur || cur.n == null) return { risk: null, note: 'داده پرواز در دسترس نیست' };
  const prev = samples.filter(s => s.t < now - 5 * MIN);
  const shortS = prev.filter(s => now - s.t <= 3 * HOUR).map(s => s.n);
  const dayS = [];
  for (let k = 1; k <= 3; k++) prev.forEach(s => { if (Math.abs(now - k * 24 * HOUR - s.t) <= 75 * MIN) dayS.push(s.n); });
  const bases = [];
  if (shortS.length >= 4) bases.push({ n: median(shortS), why: '۳ ساعت اخیر' });
  if (dayS.length >= 3) bases.push({ n: median(dayS), why: 'همین ساعت روزهای قبل' });
  const show = 'اکنون ' + cur.n + ' هواپیما در منطقه، ' + (cur.i || 0) + ' بالای ایران';
  if (!bases.length) return { risk: null, note: show + ' • در حال یادگیری (' + prev.length + ' نمونه)' };
  const ok = bases.filter(b => b.n >= 8);
  if (!ok.length) return { risk: null, note: show + ' • پوشش رادار ضعیف است' };
  const worst = ok.reduce((m, b) => (cur.n / b.n < cur.n / m.n ? b : m), ok[0]);
  const ratio = cur.n / worst.n;
  const risk = ratio >= 0.8 ? 20 : ratio >= 0.5 ? 40 : ratio >= 0.25 ? 70 : 92;
  return { risk, note: show + ' • حالت عادی (' + worst.why + ') حدود ' + Math.round(worst.n) };
}


/* ---------- بازارهای مالی (Yahoo Finance) ---------- */
const MARKET_SYMBOLS = [
  { key: 'brent', sym: 'BZ=F', name: 'نفت برنت' },
  { key: 'gold', sym: 'GC=F', name: 'طلا' },
  { key: 'vix', sym: '^VIX', name: 'شاخص ترس (VIX)' },
  { key: 'ta125', sym: '^TA125.TA', name: 'بورس تل‌آویو' },
  { key: 'es', sym: 'ES=F', name: 'آتی S&P 500' },
  { key: 'ils', sym: 'ILS=X', name: 'دلار به شکل اسرائیل' },
  { key: 'btc', sym: 'BTC-USD', name: 'بیت‌کوین (۲۴ ساعته)' },
];
function marketUrl(sym) { return 'https://query1.finance.yahoo.com/v8/finance/chart/' + encodeURIComponent(sym) + '?range=2d&interval=15m'; }
function yahooParse(text, now) {
  const j = JSON.parse(text);
  const r = j.chart && j.chart.result && j.chart.result[0];
  if (!r) throw new Error('پاسخ بازار خالی است');
  const ts = r.timestamp || [], cl = (r.indicators && r.indicators.quote && r.indicators.quote[0] && r.indicators.quote[0].close) || [];
  const pts = [];
  for (let i = 0; i < ts.length; i++) if (cl[i] != null) pts.push({ t: ts[i] * 1000, c: cl[i] });
  if (!pts.length) throw new Error('بدون داده');
  const last = pts[pts.length - 1];
  const before = ms => { for (let i = pts.length - 1; i >= 0; i--) if (pts[i].t <= last.t - ms) return pts[i].c; return null; };
  const b3 = before(3 * HOUR), b24 = before(24 * HOUR);
  return { price: last.c, t: last.t, ch3: b3 ? (last.c / b3 - 1) * 100 : null, ch24: b24 ? (last.c / b24 - 1) * 100 : null, stale: now - last.t > 90 * MIN };
}
// هر تغییر در جهتی که با تشدید جنگ می‌خواند، امتیاز می‌گیرد
function marketContrib(key, it) {
  const c3 = it.ch3 == null ? 0 : it.ch3, c24 = it.ch24 == null ? 0 : it.ch24;
  switch (key) {
    case 'brent': return (c24 >= 6 ? 30 : c24 >= 3 ? 15 : c24 >= 1.5 ? 6 : 0) + (c3 >= 2 ? 10 : 0);
    case 'gold':  return c24 >= 3 ? 20 : c24 >= 1.5 ? 10 : c24 >= 0.8 ? 4 : 0;
    case 'vix':   return it.price >= 30 ? 20 : it.price >= 25 ? 12 : (it.price >= 20 && c24 >= 15) ? 8 : 0;
    case 'ta125': return c24 <= -3 ? 20 : c24 <= -1.5 ? 8 : 0;
    case 'es':    return c24 <= -2 ? 12 : c24 <= -1 ? 5 : 0;
    case 'ils':   return c24 >= 1.5 ? 8 : 0;
    case 'btc':   return (c3 <= -3 ? 8 : 0) + (c24 <= -6 ? 10 : 0);
    default: return 0;
  }
}
function marketRisk(items) {
  const live = items.filter(i => !i.stale);
  if (!live.length) return { risk: null, note: 'بازارهای سنتی بسته‌اند (آخر هفته یا شب). با باز شدن بازار به‌روز می‌شود.' };
  const sum = live.reduce((s, i) => s + marketContrib(i.key, i), 0);
  const risk = clamp(20 + sum, 0, 100);
  const top = live.map(i => ({ n: i.name, c: marketContrib(i.key, i) })).filter(x => x.c > 0).sort((a, b) => b.c - a.c).slice(0, 2).map(x => x.n);
  return { risk, note: top.length ? 'حرکت غیرعادی: ' + top.join('، ') : 'بدون حرکت غیرعادی' };
}

/* ---------- بازار پیش‌بینی (Polymarket) ---------- */
const CROWD_QUERIES = ['US strikes Iran', 'Israel strikes Iran'];
function crowdUrl(q) { return 'https://gamma-api.polymarket.com/public-search?q=' + encodeURIComponent(q); }
function crowdParse(texts, now) {
  const out = [], seen = new Set();
  for (const t of texts) {
    let j; try { j = JSON.parse(t); } catch (e) { continue; }
    const events = Array.isArray(j) ? j : (j.events || []);
    for (const ev of events) for (const m of (ev.markets || [])) {
      const q = String(m.question || ev.title || '');
      if (!q || seen.has(q) || m.closed || m.active === false) continue;
      if (!/iran/i.test(q) || !/strike|attack|bomb|military|war\b|invade|hit\b/i.test(q) || /ceasefire|deal|agreement|talks|nuclear test/i.test(q)) continue;
      const end = Date.parse(m.endDate || m.end_date_iso || ev.endDate || '');
      if (!isNaN(end) && (end - now > 60 * 24 * HOUR || end < now)) continue;   // فقط پرسش‌های کوتاه‌مدت
      let p = null;
      try { const pr = JSON.parse(m.outcomePrices), oc = JSON.parse(m.outcomes); const yi = oc.findIndex(x => /^yes$/i.test(x)); p = parseFloat(pr[yi >= 0 ? yi : 0]); } catch (e) { }
      if (p == null || isNaN(p)) continue;
      seen.add(q);
      out.push({ q, p, end: isNaN(end) ? null : end, vol: +m.volume || 0 });
    }
  }
  return out.sort((a, b) => b.p - a.p).slice(0, 4);
}
function crowdRisk(items, prev, now) {
  if (!items.length) return { risk: null, note: 'پرسش فعالی درباره حمله به ایران پیدا نشد' };
  const top = items[0];
  let risk = top.p >= 0.7 ? 80 : top.p >= 0.5 ? 60 : top.p >= 0.35 ? 45 : top.p >= 0.2 ? 32 : 20;
  let jump = 0;
  const old = (prev && prev[top.q] || []).filter(x => now - x.t >= 20 * HOUR).pop();
  if (old) jump = top.p - old.p;
  if (jump >= 0.15) risk = clamp(risk + 15, 0, 100);
  return { risk, note: 'احتمال حمله (کوتاه‌مدت): ' + Math.round(top.p * 100) + '٪' + (jump >= 0.15 ? ' • جهش ' + Math.round(jump * 100) + ' واحدی در ۲۴ ساعت' : ''), jump };
}


/* ---------- هموارسازی نمره: بالا رفتن سریع (نیمه‌عمر ۳ ساعت)، پایین آمدن آهسته (۱۲ ساعت) ---------- */
function ema(prev, raw, dtMs) {
  if (prev == null || isNaN(prev)) return raw;
  const hl = raw > prev ? 3 * HOUR : 12 * HOUR;
  const a = 1 - Math.pow(0.5, Math.max(0, dtMs) / hl);
  return prev + (raw - prev) * a;
}
function downsample(arr, n) {
  if (arr.length <= n) return arr;
  const out = [], step = arr.length / n;
  for (let i = 0; i < n; i++) out.push(arr[Math.floor(i * step)]);
  out.push(arr[arr.length - 1]);
  return out;
}

/* ---------- لحن اظهارات رهبران آمریکا و اسرائیل ---------- */
const LEADERS = /trump|netanyahu|hegseth|rubio|vance|katz|zamir|ترامپ|نتانیاهو|هگست|روبیو|ونس|کاتز/;
const TONE_ESC = /strike|attack|no deal|wipe out|ultimatum|regime change|warns?|warned|threat|all options|finish the job|job to finish|obliterate|deadline|hit hard|حمله|تهدید|هشدار داد|ضرب.?الاجل|تغییر رژیم|بدون توافق|نابود/;
const TONE_DE = /\bdeal\b|talks|peace|ceasefire|negotiat|agreement|reduce tensions|avoid war|diplomacy|توافق|مذاکره|آتش.?بس|صلح|کاهش تنش|دیپلماسی/;
function toneRisk(items, now) {
  now = now || Date.now();
  let esc = 0, de = 0; const seen = new Set();
  for (const it of items) {
    if (isIranianSource(it)) continue;
    if (now - (it.ts || now) > 48 * HOUR) continue;
    const n = norm(it.title);
    if (!LEADERS.test(n) || !IRAN_REL.test(n) || seen.has(n)) continue;
    seen.add(n);
    const e = TONE_ESC.test(n), d = TONE_DE.test(n.replace(/no deal|بدون توافق/g, ''));
    if (e && !d) esc++; else if (d && !e) de++;      // تیترهای دوبه‌پهلو نادیده گرفته می‌شوند
  }
  const n = esc + de;
  if (n < 3) return { risk: null, note: 'اظهارنظر کافی برای سنجش لحن نبود (' + n + ' از ۳)', esc, de };
  const ratio = esc / n;
  const risk = clamp(Math.round(ratio * ratio * 150), 5, 95);
  return { risk, note: esc + ' اظهار تند در برابر ' + de + ' اظهار مذاکره‌ای در ۴۸ ساعت اخیر', esc, de };
}

/* ---------- نمره‌دهی ---------- */
function levelOf(score) {
  if (score <= 25) return { key: 'calm', name: 'آرام' };
  if (score <= 50) return { key: 'caution', name: 'محتاط' };
  if (score <= 75) return { key: 'warning', name: 'هشدار' };
  return { key: 'critical', name: 'بحرانی' };
}
function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }

function computeScore(events, weights, ext, now) {
  now = now || Date.now();
  ext = ext || {};
  weights = weights || {};
  // اثر کم‌شونده: هر خبرِ تکراری از یک موضوع کمتر اثر می‌گذارد
  const byLabel = {};
  for (const e of events) (byLabel[e.ind + '|' + e.label] = byLabel[e.ind + '|' + e.label] || []).push(e);
  const eff = [];
  for (const k in byLabel) {
    byLabel[k].sort((a, b) => b.ts - a.ts).forEach((e, i) => {
      const f = i === 0 ? 1 : (i < 3 ? 0.5 : 0);
      const ageH = Math.max(0, (now - e.ts) / HOUR);
      const decay = Math.pow(0.5, ageH / HALF_LIFE_H);
      eff.push(Object.assign({}, e, { effect: e.pts * PT * f * decay }));
    });
  }
  const indicators = INDICATORS.map(def => {
    const w = weights[def.id] != null ? weights[def.id] : (effCfg().weights[def.id] != null ? effCfg().weights[def.id] : def.weight);
    let risk = null, note = def.note || '';
    if (def.available) {
      if (def.id === 'internet' || def.id === 'flights' || def.id === 'crowd' || def.id === 'tone') {
        const x = ext[def.id];
        if (x && x.risk != null) { risk = x.risk; note = x.note || ''; }
        else note = (x && x.note) || 'هنوز اندازه‌گیری نشده';
      } else {
        const evs = eff.filter(e => e.ind === def.id);
        risk = clamp(BASE_RISK + evs.reduce((s, e) => s + e.effect, 0), 0, 100);
        if (def.id === 'markets') {
          const m = ext.markets;
          if (m && m.risk != null) { risk = Math.max(risk, m.risk); note = m.note || ''; }
          else if (!evs.length) { risk = null; note = (m && m.note) || 'بدون داده'; }
        }
      }
    }
    return { id: def.id, name: def.name, weight: w, risk, available: def.available && risk !== null, note };
  });
  const live = indicators.filter(i => i.available && i.weight > 0);
  const wsum = live.reduce((s, i) => s + i.weight, 0) || 1;
  const avg = live.reduce((s, i) => s + i.risk * i.weight, 0) / wsum;
  // نشانگرهای پرنوسان نباید به‌تنهایی نمره کل را بالا بکشند: برای «بالاترین نشانگر» سقف دارند
  const CAP = { tone: 55, crowd: 70, markets: 75, flights: 85, internet: 70 };
  const max = live.reduce((m, i) => Math.max(m, Math.min(i.risk, CAP[i.id] || 100)), 0);
  // ضریب هم‌راستایی: وقتی چند نشانگر مستقل همزمان بالا باشند، اثرشان از جمع ساده بیشتر است
  const elevated = live.filter(i => i.risk >= 50).length;
  const mult = elevated >= 4 ? 1.25 : elevated === 3 ? 1.15 : elevated === 2 ? 1.08 : 1;
  let final = Math.round(clamp((0.6 * avg + 0.4 * max) * mult, 0, 100));
  // «بحرانی» (بالاتر از ۷۵) فقط برای حمله تأییدشده است؛ پیش از آن بالاترین سطح «هشدار» است
  if (!(ext.alert && (ext.alert.level === 'full' || ext.alert.level === 'standby' || ext.alert.level === 'capital'))) final = Math.min(final, 75);
  // خبر حمله تأییدشده، نمره را مستقیم بالا می‌برد
  if (ext.alert && (ext.alert.level === 'full' || ext.alert.level === 'capital')) final = Math.max(final, 95);
  else if (ext.alert && ext.alert.level === 'standby') final = Math.max(final, 80);
  else if (ext.alert && ext.alert.level === 'incident') final = Math.max(final, 45);
  return { final, level: levelOf(final), indicators, effective: eff, elevated, mult };
}

const api = { PROVINCES, PLACE_FA, DEFAULT_WATCH, provinceOf, family, configure, getConfig, getSources, getWatch, rulesCatalog, validatePack, matchesIgnore, attackHits, explainReject, ema, downsample, toneRisk, MARKET_SYMBOLS, marketUrl, yahooParse, marketContrib, marketRisk, CROWD_QUERIES, crowdUrl, crowdParse, crowdRisk, pubGroup, isIranianSource, isConditional, TRUSTED_PUB, readinessState, flightRisk, SOURCES, INDICATORS, BASE_RISK, PT, norm, stripHtml, parseFeed, extractArticleText, sentences,
  isHypothetical, looksLikeAttack, verifyAttack, alertState, classify, computeScore, levelOf, citiesIn };
if (typeof module !== 'undefined' && module.exports) module.exports = api;
root.Engine = api;
})(typeof window !== 'undefined' ? window : globalThis);
