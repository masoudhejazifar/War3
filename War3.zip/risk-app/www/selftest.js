/* مجموعه تست دقت: تیترهای واقعی و ساختگی با پاسخ درست.
   هر بار که قانون‌ها عوض می‌شوند باید همه موارد قبول شوند. */
(function (root) {
'use strict';
const C = (id, source, group, title, body, expect) => ({ id, source, group, title, body: body || '', expect });
const CASES = [
  // ---- نشانه‌های واقعی: باید گرفته شوند ----
  C('embassy-ordered-departure', 'رویترز', 'reuters', 'US embassy ordered departure of non-emergency staff as strike on Iran looms', '', { ev: [['embassy', 'A']] }),
  C('iran-airspace-closed', 'رویترز', 'reuters', 'Iran closes its entire airspace until further notice', '', { ev: [['airspace', 'A']] }),
  C('tse-halted', 'رویترز', 'reuters', 'Tehran Stock Exchange halted as Israeli strikes hit Iranian capital', '', { ev: [['civil', 'A']] }),
  C('schools-closed-security', 'AP', 'ap', 'Iran: schools and universities closed until further notice, Supreme National Security Council says after attack', '', { ev: [['civil', 'A']] }),
  C('rosatom-evac', 'رویترز', 'reuters', "Russia evacuates Rosatom staff from Iran's Bushehr nuclear plant", '', { ev: [['military', 'B']] }),
  C('axios-drawdown', 'Axios', 'axios', 'US is reducing staffing at 4 Middle East embassies over increased threats from Iran', '', { ev: [['embassy', 'B']], noEase: true }),
  C('airlines-suspend', 'الجزیره', 'aljazeera', 'Airlines suspend flights to Tehran as US military buildup near Iran continues', '', { ev: [['airspace', 'B']] }),
  C('mobile-cut', 'BBC', 'bbc', 'Mobile phone services cut across Tehran', '', { ev: [['civil', 'B']] }),
  C('imminent', 'رویترز', 'reuters', 'Western official says US strike on Iran imminent', '', { ev: [['military', 'B']] }),
  C('hormuz-tanker', 'رویترز', 'reuters', 'Tanker attacked in Strait of Hormuz, UKMTO issues advisory', '', { ev: [['markets', 'B']] }),
  C('home-front', 'AP', 'ap', 'Israel Home Front Command issues new restrictions on gatherings amid Iran threat', '', { ev: [['military', 'B']] }),
  C('qatar-airspace', 'رویترز', 'reuters', 'Qatar closes airspace as Iran tensions mount', '', { ev: [['airspace', 'B']], noEv: [['airspace', 'A']] }),
  C('carrier', 'رویترز', 'reuters', 'US sends aircraft carrier to the Gulf as tensions with Iran escalate', '', { ev: [['military', 'C']] }),
  C('iaea', 'رویترز', 'reuters', 'IAEA board report says Iran enriched uranium stockpile growing', '', { ev: [['news', 'C']] }),
  C('embassy-reopen', 'رویترز', 'reuters', 'French embassy in Tehran reopens after talks ease tensions', '', { ev: [['embassy', 'ease']] }),
  // ---- باید نادیده گرفته شوند ----
  C('ukraine-ceasefire', 'AP', 'ap', 'Melania Trump brokers a ceasefire deal in Russian-occupied Ukrainian city', '', { none: true }),
  C('lng', 'رویترز', 'reuters', 'Top LNG exporter QatarEnergy in talks to buy US LNG from Woodside', '', { none: true }),
  C('schools-pollution', 'ایرنا', 'irna', 'Schools closed in Tehran until further notice due to air pollution', '', { none: true }),
  C('schools-sandstorm', 'AP', 'ap', 'Schools and offices closed in Tehran after sandstorm blankets Iran', '', { none: true }),
  C('what-if', 'tabloid', 'x', 'What happens if the US strikes Tehran? Experts warn', 'If the US bombed Tehran, explosions could hit the city.', { none: true, attack: 'reject' }),
  C('air-defence-drill', 'رویترز', 'reuters', 'Iran holds air defence drill near Isfahan', 'The drill was planned months ago.', { none: true }),
  C('irna-commentary', 'ایرنا', 'irna', 'محاسبات آمریکا درباره اهداف جنگ ایران اشتباه بود', '', { none: true }),
  C('rial', 'رویترز', 'reuters', 'Iran rial hits record low against dollar', '', { none: true }),
  C('missile-test', 'رویترز', 'reuters', 'Iran conducts missile test in Semnan province', '', { none: true, attack: 'reject' }),
  // ---- اشتباه‌های دیده‌شده روی گوشی (آبان ۱۴۰۵) ----
  C('wrestling-rank', 'مهر', 'mehr', 'ردهبندی نهایی کشتی آزاد جهان مشخص شد؛ ایران با دو پله سقوط سوم شد', 'تیم ایران با تأمین امتیاز و بسته شدن مسابقات سوم شد', { none: true }),
  C('wrestling-city', 'ایسنا', 'isna', 'شهر المپیکی‌های ایران روی دور استقبال از مدال آوران کشتی جهانی', 'زمین ورزشی و تهدید به بسته شدن سالن', { none: true }),
  C('diplomacy-body-hormuz', 'الجزیره', 'aljazeera', 'Iran and US explore diplomacy amid rising threats of war', 'Talks continue while tankers cross the Strait of Hormuz under threat; shipping advisories remain.', { none: true }),
  C('embassy-protest', 'Reuters', 'reuters', 'Iranians protest at UK embassy in Tehran, demand closure', '', { none: true }),
  C('hormuz-in-title', 'Reuters', 'reuters', 'Gunmen attack tanker near Strait of Hormuz, advisory issued', '', { ev: [['markets', 'B']] }),
  // ---- انکار، برنامه، تهدید و گفتار: حمله نیستند (آلارم اشتباه = فاجعه) ----
  C('neg-en-1', 'Reuters', 'reuters', 'Trump: no immediate plan to attack Iran', 'Trump told reporters there is no immediate plan to attack Iran.', { attack: 'reject' }),
  C('neg-en-2', 'AP', 'ap', 'Trump says US will not strike Iran before the midterms', 'Trump said strikes on Iran are not planned before the election.', { attack: 'reject' }),
  C('neg-en-3', 'BBC', 'bbc', 'White House denies plans for strikes on Iran', 'Officials denied any plan to strike Iranian cities.', { attack: 'reject' }),
  C('neg-fa-1', 'ایرنا', 'irna', 'ادعای ترامپ: آمریکا هیچ برنامه فوری‌ برای حمله به ایران ندارد', 'ترامپ گفت آمریکا هیچ برنامه فوری برای حمله به ایران ندارد. او افزود در صورت لزوم عملیات گسترده انجام می‌شود.', { attack: 'reject' }),
  C('neg-fa-2', 'مهر', 'mehr', 'ترامپ: هیچ برنامه فوری برای حمله به ایران ندارم', 'ترامپ در گفت‌وگو با فاکس نیوز گفت هیچ برنامه فوری برای حمله به ایران ندارم. حمله به قشم یک عملیات کوچک بود.', { attack: 'reject' }),
  C('threat-en', 'Reuters', 'reuters', 'Iran warns any attack on Tehran will meet decisive response', '', { attack: 'reject' }),
  C('threat-fa', 'تسنیم', 'tasnim', 'هرگونه حمله به تهران با پاسخ قاطع مواجه می‌شود', 'فرمانده سپاه گفت هرگونه حمله به تهران پاسخ قاطع خواهد داشت.', { attack: 'reject' }),
  C('plan-en-1', 'Reuters', 'reuters', 'Israel ready to strike Iran, officials say', 'Israeli officials said the military is ready to strike Iran if ordered.', { attack: 'reject' }),
  C('plan-en-2', 'NYT', 'nyt', 'US weighing strikes on Iran after midterms, officials say', '', { attack: 'reject' }),
  C('plan-en-3', 'Axios', 'axios', 'Netanyahu urges Trump to strike Iran after the election', '', { attack: 'reject' }),
  C('plan-en-4', 'WSJ', 'wsj', 'Pentagon plans strikes on Iranian nuclear sites near Isfahan', '', { attack: 'reject' }),
  C('analysis-en', 'Guardian', 'guardian', 'Why a US strike on Tehran would be a mistake', '', { attack: 'reject' }),
  C('tehran-metonym', 'Reuters', 'reuters', 'Tehran warns Washington after Qeshm strike', '', { attack: 'reject' }),
  C('defence-fa', 'فارس', 'fars', 'آمادگی کامل نیروهای مسلح برای دفاع در برابر هر حمله آمریکا به ایران', '', { attack: 'reject' }),
  // ---- حمله‌های واقعی: باید گرفته شوند ----
  C('real-trump-confirms', 'NZ Herald', 'nzherald', 'Trump confirms strikes on Iran as Tehran warns against return to war', 'Trump confirmed that US forces struck an anti-aircraft facility on Qeshm Island. IRNA reported five explosions on the island.', { attack: 'ok', scale: 'limited' }),
  C('real-qeshm-nbc', 'NBC', 'nbc', "U.S. military carries out limited strikes on Iran's Qeshm Island, U.S. officials say", 'The U.S. military carried out limited strikes on Qeshm Island, officials said. Iranian state media reported five explosions.', { attack: 'ok', scale: 'limited' }),
  C('real-us-strikes', 'Reuters', 'reuters', 'US strikes Qeshm Island, Iranian media report explosions', 'Iranian media reported explosions on Qeshm Island after US strikes.', { attack: 'ok' }),
  C('real-karaj', 'Reuters', 'reuters', 'Missiles hit Karaj, residents report explosions', 'Residents of Karaj reported explosions after missiles hit the city today.', { attack: 'ok', scale: 'limited' }),
  C('real-karaj-fa', 'بی‌بی‌سی', 'bbc', 'حمله هوایی به کرج؛ صدای انفجار در چند نقطه شهر شنیده شد', 'امروز صدای انفجار در کرج شنیده شد و شاهدان از حمله هوایی خبر دادند.', { attack: 'ok' }),
  C('real-natanz', 'AP', 'ap', 'Israeli airstrike hits Natanz, Iranian media report', 'An Israeli airstrike hit the Natanz area today, state media reported.', { attack: 'ok' }),
  C('real-tehran-karaj', 'رویترز', 'reuters', 'US and Israel strike Tehran and Karaj; explosions reported in both cities', 'Explosions were reported today in Tehran and Karaj after US and Israeli strikes.', { attack: 'ok', scale: 'wide' }),
  C('real-gulfnews', 'Gulf News', 'gulfnews', "Middle East conflict: US carries out defensive strikes on Iran's Qeshm Island near Strait of Hormuz as tensions escalate", "The US has carried out limited defensive strikes on Iran's Qeshm Island. Iranian state media reported five explosions.", { attack: 'ok', scale: 'limited' }),
  C('talk-midterm', 'NYT', 'nyt', "As Trump's Midterm Deadline Looms, Gulf Countries Brace for Possible Renewal of Iran War", 'Gulf countries fear a return to strikes on Iran.', { attack: 'reject', none: true }),
  C('talk-pezeshkian', 'NZ Herald', 'nzherald', 'Pezeshkian urges dialogue: no one will benefit from this war if it reignites', '', { attack: 'reject' }),
  C('talk-scenario', 'tabloid', 'x', 'Scenario: missiles hit Tehran', '', { attack: 'reject' }),
  // ---- بدون نشانه کافی: رد می‌شود ----
  C('unattributed-blast', 'AP', 'ap', 'Explosions rock Tehran, residents report', 'Residents of Tehran reported loud explosions today.', { attack: 'reject' }),
  C('drone-shot-down', 'ایرنا', 'irna', 'Iran says air defence shot down drone over Isfahan', 'The drone was shot down.', { attack: 'reject' }),
  // ---- حمله: تشخیص حمله نظامی، حادثه، و مقیاس ----
  C('strike-tehran', 'رویترز', 'reuters', 'Explosions heard in Tehran, witnesses report air strikes', 'Witnesses told Reuters that explosions struck Tehran today. Air strikes hit sites in the capital.', { attack: 'ok', scale: 'limited' }),
  C('strike-wide', 'رویترز', 'reuters', 'US and Israel launch strikes on Iran, explosions reported in Tehran, Isfahan and Qom', 'Explosions were reported today in Tehran, Isfahan and Qom as strikes hit several cities.', { attack: 'ok', scale: 'wide' }),
  C('strike-wide-fa', 'بی‌بی‌سی', 'bbc', 'آغاز حمله هوایی گسترده به چند شهر ایران؛ انفجار در تهران و اصفهان', 'امروز صدای انفجار در تهران و اصفهان شنیده شد. حمله هوایی چند شهر را هدف قرار داد.', { attack: 'ok', scale: 'wide' }),
  C('gas-en', 'رویترز', 'reuters', 'Gas explosion hits residential building in Tehran, two injured', 'A gas explosion today in Tehran injured two people.', { attack: 'reject' }),
  C('gas-fa', 'ایرنا', 'irna', 'انفجار گاز در یک ساختمان مسکونی در تهران؛ دو نفر مجروح شدند', 'انفجار گاز امروز در تهران رخ داد.', { attack: 'reject' }),
  C('fireworks', 'AP', 'ap', 'Fireworks explosion injures dozens in Isfahan', 'The blast today in Isfahan injured dozens.', { attack: 'reject' }),
  C('unknown-blast', 'رویترز', 'reuters', 'Explosion heard in Shiraz, cause unknown', 'Residents in Shiraz reported an explosion today.', { attack: 'reject' }),
  C('sonic-boom', 'AP', 'ap', 'Sonic boom heard in Tehran, officials say', 'A loud explosion-like noise was heard in Tehran today.', { attack: 'reject' }),
  C('limited-drone', 'رویترز', 'reuters', 'Israeli drone strike hits vehicle near Kermanshah, one killed', 'An Israeli drone strike hit a vehicle near Kermanshah today, killing one person.', { attack: 'ok', scale: 'limited' }),
  C('anniversary', 'AP', 'ap', 'Iranians mark anniversary of the 12-day war with strikes on Tehran remembered', 'On the anniversary of last year strikes in Tehran, ceremonies were held.', { attack: 'reject' }),
];


/* آزمون سطح آلارم: استقلال منابع (خبرگزاری‌های دولتی ایران یک خانواده‌اند)، استان‌های حساس، مقیاس */
function alertCases(E) {
  const now = Date.now();
  const V = (group, cities, scale, level) => ({ source: group, group, title: group + ' ' + cities.join('/'), ts: now - 5 * 60000, cities, scale, textLevel: level || 'full', provinces: Array.from(new Set(cities.map(E.provinceOf).filter(Boolean))) });
  const T = [
    ['reuters+irna Tehran (limited) -> capital', [V('reuters', ['Tehran'], 'limited'), V('irna', ['Tehran'], 'limited')], null, 'capital'],
    ['reuters+ap Karaj (limited) -> capital', [V('reuters', ['Karaj'], 'limited'), V('ap', ['Karaj'], 'limited')], null, 'capital'],
    ['irna+mehr Tehran only -> NOT capital/full (one family)', [V('irna', ['Tehran'], 'wide'), V('mehr', ['Tehran'], 'wide')], null, 'incident'],
    ['irna+tasnim+fars wide Isfahan -> incident', [V('irna', ['Isfahan'], 'wide'), V('tasnim', ['Isfahan'], 'wide'), V('fars', ['Isfahan'], 'wide')], null, 'incident'],
    ['reuters wide Isfahan alone -> standby', [V('reuters', ['Isfahan', 'Qom'], 'wide')], null, 'standby'],
    ['irna wide alone -> incident', [V('irna', ['Isfahan', 'Qom'], 'wide')], null, 'incident'],
    ['reuters+bbc wide Isfahan+Qom -> full', [V('reuters', ['Isfahan', 'Qom'], 'wide'), V('bbc', ['Isfahan', 'Qom'], 'wide')], null, 'full'],
    ['reuters+bbc limited Qeshm -> incident (not war)', [V('reuters', ['Qeshm'], 'limited'), V('bbc', ['Qeshm'], 'limited')], null, 'incident'],
    ['watch=[tehran] only: Karaj pair -> incident', [V('reuters', ['Karaj'], 'limited'), V('ap', ['Karaj'], 'limited')], ['tehran'], 'incident'],
    ['two independent non-Iranian headlines (summary) -> full', [V('reuters', ['Isfahan', 'Qom'], 'wide', 'summary'), V('bbc', ['Isfahan', 'Qom'], 'wide', 'summary')], null, 'full'],
    ['reuters(summary)+irna(summary) -> incident (needs a full text)', [V('reuters', ['Isfahan', 'Qom'], 'wide', 'summary'), V('irna', ['Isfahan', 'Qom'], 'wide', 'summary')], null, 'incident'],
    ['reuters(summary)+irna(full) Tehran -> capital', [V('reuters', ['Tehran'], 'limited', 'summary'), V('irna', ['Tehran'], 'limited', 'full')], null, 'capital'],
  ];
  const fails = [];
  for (const [name, items, watch, expect] of T) {
    const got = E.alertState(items, now, watch || undefined).level;
    if (got !== expect) fails.push('alert: ' + name + ' → انتظار ' + expect + '، شد ' + got);
  }
  return { total: T.length, fails };
}

function run(E, extra) {
  const now = Date.now();
  const fails = [];
  const extraCases = (extra || []).map((x, i) => C('pack-' + i, x.source || 'x', x.group || 'x', x.title || '', x.body || '', x.expect || {}));
  for (const c of CASES.concat(extraCases)) {
    const it = { title: c.title, body: c.body, source: c.source, group: c.group, ts: now - 5 * 60000, link: 'st:' + c.id, fullText: !!c.body };
    const evs = E.classify(it, now);
    const has = (ind, tier) => evs.some(e => e.ind === ind && e.tier === tier);
    const x = c.expect;
    (x.ev || []).forEach(([ind, tier]) => { if (!has(ind, tier)) fails.push(c.id + ': باید ' + ind + '/' + tier + ' می‌گرفت. گرفت: ' + (evs.map(e => e.ind + '/' + e.tier).join(', ') || 'هیچ')); });
    (x.noEv || []).forEach(([ind, tier]) => { if (has(ind, tier)) fails.push(c.id + ': نباید ' + ind + '/' + tier + ' می‌گرفت'); });
    if (x.noEase && evs.some(e => e.tier === 'ease')) fails.push(c.id + ': نباید «کاهش تنش» حساب می‌شد');
    if (x.none && evs.some(e => e.pts > 0 && e.tier !== 'ease')) fails.push(c.id + ': نباید نشانه می‌گرفت. گرفت: ' + evs.map(e => e.ind + '/' + e.tier).join(', '));
    if (x.attack) {
      const la = E.looksLikeAttack(it);
      const v = la ? E.verifyAttack(it, now) : { ok: false, reason: 'looksLikeAttack=false' };
      if (x.attack === 'ok' && !v.ok) fails.push(c.id + ': باید حمله تشخیص داده می‌شد. دلیل رد: ' + v.reason);
      if (x.attack === 'reject' && v.ok) fails.push(c.id + ': نباید حمله حساب می‌شد (مقیاس ' + v.scale + ')');
      if (x.scale && v.ok && v.scale !== x.scale) fails.push(c.id + ': مقیاس باید ' + x.scale + ' می‌بود، شد ' + v.scale);
    }
  }
  const ac = alertCases(E);
  fails.push(...ac.fails);
  const total = CASES.length + extraCases.length + ac.total;
  return { total, passed: total - new Set(fails.map(f => f.split(':')[0])).size, failures: fails };
}
const api = { CASES, run };
if (typeof module !== 'undefined' && module.exports) module.exports = api;
root.SelfTest = api;
})(typeof window !== 'undefined' ? window : globalThis);
