/* سناریوهای آزمایشی — برای دیدن رفتار اپ بدون نیاز به خبر واقعی */
(function (root) {
'use strict';
const M = 60e3;
function mk(source, group, title, body, minsAgo, now) {
  return { source, group, title, body, link: 'demo://' + group + '/' + encodeURIComponent(title).slice(0, 40),
    ts: now - minsAgo * M, fullText: true };
}

function mkt(level) {
  const L = { calm: [0.4, 0.2, 16, 0.3, 0.1, 0.1, 0.5], tension: [3.4, 1.2, 22, -1.0, -0.6, 0.6, -1.0], ready: [6.4, 2.1, 27, -3.5, -1.8, 1.6, -4.2], war: [9.2, 3.1, 33, -5.2, -2.6, 2.4, -7.0] }[level];
  const names = [['brent','نفت برنت',72.4],['gold','طلا',5120],['vix','شاخص ترس (VIX)',L[2]],['ta125','بورس تل‌آویو',2410],['es','آتی S&P 500',6900],['ils','دلار به شکل اسرائیل',3.62],['btc','بیت‌کوین (۲۴ ساعته)',92000]];
  const items = names.map((n, i) => ({ key: n[0], name: n[1], price: n[2], ch3: L[i] / 3, ch24: n[0] === 'vix' ? 4 : L[i], stale: false }));
  const E = (typeof window !== 'undefined' && window.Engine) || require('./engine.js');
  const r = E.marketRisk(items);
  return { risk: r.risk, note: r.note, items, t: Date.now() };
}
function crowd(p, jump) {
  const risk = p >= 0.7 ? 80 : p >= 0.5 ? 60 : p >= 0.35 ? 45 : p >= 0.2 ? 32 : 20;
  return { risk: jump ? Math.min(100, risk + 15) : risk, note: 'احتمال حمله (کوتاه‌مدت): ' + Math.round(p * 100) + '٪' + (jump ? ' • جهش ' + Math.round(jump * 100) + ' واحدی در ۲۴ ساعت' : ''),
    items: [{ q: 'US strikes Iran by November 30?', p }, { q: 'Israel strikes Iran by December 31?', p: Math.max(0.05, p - 0.1) }], t: Date.now() };
}
const SCENARIOS = {
  calm: {
    label: 'آرام',
    markets: () => mkt('calm'), crowd: () => crowd(0.12),
    internet: { risk: 15, note: 'اینترنت عادی' }, flights: { risk: 20, note: 'ترافیک عادی' },
    items: n => [
      mk('رویترز','reuters','Iran and European powers agree to hold new talks','Diplomats said talks on the nuclear file would resume next month. Negotiators described the atmosphere as constructive and flights across the region are operating normally.',90,n),
      mk('BBC فارسی','bbc','بازگشایی حریم هوایی ایران و از سرگیری پروازها','شرکت‌های هواپیمایی پروازهای ایران را از سر گرفتند.',200,n),
    ],
  },
  tension: {
    label: 'تنش بالا می‌رود',
    markets: () => mkt('tension'), crowd: () => crowd(0.27),
    internet: { risk: 15, note: 'اینترنت عادی' }, flights: { risk: 40, note: 'ترافیک کمی کمتر از عادی' },
    items: n => [
      mk('رویترز','reuters','US sends aircraft carrier to the Gulf as tensions with Iran escalate','The Pentagon said it deployed a carrier strike group. Officials warned of further escalation.',50,n),
      mk('الجزیره','aljazeera','US issues level 4 travel advisory urging citizens not to travel to Iran or Iraq','The State Department issued a level 4 travel advisory.',70,n),
      mk('AP','ap','Airlines cancel flights to Iran as travel restrictions expand','Several airlines suspended flights to Tehran.',35,n),
      mk('رویترز','reuters','Trump warns Iran of strikes if no deal reached this week','Trump warned Iran of strikes.',30,n),
      mk('AP','ap','Trump says no deal with Iran, threatens to wipe out nuclear sites','Trump threatened Iran.',45,n),
      mk('الجزیره','aljazeera','Netanyahu says job to finish against Iran','Netanyahu said Israel has a job to finish against Iran.',50,n),
      mk('BBC فارسی','bbc','جلسه اضطراری شورای امنیت درباره ایران','شورای امنیت به صورت اضطراری درباره ایران تشکیل جلسه داد.',25,n),
    ],
  },
  ready: {
    label: 'شب قبل از حمله (آماده‌باش)',
    markets: () => mkt('ready'), crowd: () => crowd(0.56, 0.2),
    internet: { risk: 15, note: 'اینترنت عادی' }, flights: { risk: 70, note: 'ترافیک بسیار کمتر از عادی' },
    items: n => [
      mk('رویترز','reuters','US embassy orders departure of non-emergency staff amid Iran tensions, ambassador tells staff to leave today','The State Department ordered departure of non-emergency embassy personnel and their families. Staff wishing to leave should do so today while commercial flights remain available.',120,n),
      mk('الجزیره','aljazeera','Airlines suspend flights to Tehran as US military buildup near Iran nears completion','Several airlines cancelled flights and Turkish carriers suspended service. Officials said the buildup was nearing completion.',90,n),
      mk('AP','ap','Russia evacuates specialists from Iran Bushehr plant as tensions peak','Rosatom said it was evacuating staff from Iran. Moscow urged all sides to avoid targeting nuclear sites.',60,n),
    ],
  },
  incident: {
    label: 'حادثه محدود یا انفجار گاز (آلارم نباید بخورد)',
    internet: { risk: 15, note: 'اینترنت عادی' }, flights: { risk: 20, note: 'ترافیک عادی' },
    markets: () => mkt('calm'), crowd: () => crowd(0.15),
    items: n => [
      mk('ایرنا','irna','انفجار گاز در یک ساختمان مسکونی در تهران؛ دو نفر مجروح شدند','انفجار گاز امروز در تهران رخ داد و آتش‌نشانی به محل رفت.',8,n),
      mk('رویترز','reuters','Israeli drone strike hits vehicle near Kermanshah, one killed','An Israeli drone strike hit a vehicle near Kermanshah today, killing one person.',12,n),
    ],
  },
  full: {
    label: 'تأیید دو منبع، خارج از تهران (آلارم کامل)',
    markets: () => mkt('war'), crowd: () => crowd(0.8),
    internet: { risk: 70, note: 'هم سایت داخلی و هم خارجی باز نشد' }, flights: { risk: 92, note: 'آسمان تقریباً خالی است' },
    items: n => [
      mk('رویترز','reuters','US and Israel launch strikes on Iran, explosions reported in Isfahan and Qom','Witnesses told Reuters that explosions struck Isfahan and Qom today. Air strikes hit sites in several cities, residents said.',6,n),
      mk('BBC فارسی','bbc','حمله هوایی به اصفهان و قم؛ شاهدان از انفجار در چند شهر خبر می‌دهند','ساعاتی پیش صدای انفجار در اصفهان و قم شنیده شد. شاهدان می‌گویند حمله هوایی چند شهر را هدف قرار داد.',3,n),
    ],
  },
  denial: {
    label: 'انکار حمله (ایرنا و مهر؛ آلارم نباید بخورد)',
    internet: { risk: 15, note: 'اینترنت عادی' }, flights: { risk: 20, note: 'ترافیک عادی' },
    markets: () => mkt('calm'), crowd: () => crowd(0.2),
    items: n => [
      mk('ایرنا','irna','ادعای ترامپ: آمریکا هیچ برنامه فوری‌ برای حمله به ایران ندارد','ترامپ گفت آمریکا هیچ برنامه فوری برای حمله به ایران ندارد. او افزود در صورت لزوم عملیات گسترده انجام می‌شود.',20,n),
      mk('مهر','mehr','ترامپ: هیچ برنامه فوری برای حمله به ایران ندارم','ترامپ در گفت‌وگو با فاکس نیوز گفت هیچ برنامه فوری برای حمله به ایران ندارم.',15,n),
      mk('NZ Herald','nzherald','Trump confirms strikes on Iran as Tehran warns against return to war','Trump confirmed that US forces struck an anti-aircraft facility on Qeshm Island. IRNA reported five explosions on the island.',60,n),
    ],
  },
  clickbait: {
    label: 'تیتر زرد (باید رد شود)',
    markets: () => mkt('calm'), crowd: () => crowd(0.15),
    internet: { risk: 15, note: 'اینترنت عادی' }, flights: { risk: 20, note: 'ترافیک عادی' },
    items: n => [
      mk('سایت زرد','yellow','اگر جنگ شروع شد، این اتفاق در تهران می‌افتد! کلیک کنید','اگر جنگ شروع شود ممکن است حمله به تهران رخ دهد و انفجار در تهران محتمل است. کارشناسان هشدار می‌دهند.',10,n),
      mk('Tabloid','tabloid','What happens if the US strikes Tehran? Experts warn','If the US bombed Tehran, explosions could hit the city. Analysts warn this scenario is possible.',12,n),
      mk('رویترز','reuters','Iran holds air defence drill near Isfahan','Iran held an annual air defence exercise in Isfahan province on Tuesday. The drill was planned months ago.',30,n),
    ],
  },
  single: {
    label: 'خبر حمله از یک منبع',
    markets: () => mkt('ready'), crowd: () => crowd(0.6),
    internet: { risk: 15, note: 'اینترنت عادی' }, flights: { risk: 40, note: 'کمی کمتر از عادی' },
    items: n => [
      mk('رویترز','reuters','US and Israel launch strikes on Iran, explosions reported in Tehran and Isfahan','Witnesses told Reuters that explosions struck Tehran and Isfahan today. Air strikes hit sites in several cities, residents said.',4,n),
    ],
  },
  capital: {
    label: 'حمله به تهران (آلارم ویژه پایتخت)',
    markets: () => mkt('war'), crowd: () => crowd(0.88),
    internet: { risk: 70, note: 'هم سایت داخلی و هم خارجی باز نشد' }, flights: { risk: 92, note: 'آسمان تقریباً خالی است' },
    items: n => [
      mk('رویترز','reuters','US and Israel launch strikes on Iran, explosions reported in Tehran and Isfahan','Witnesses told Reuters that explosions struck Tehran and Isfahan today. Air strikes hit sites in several cities, residents said.',6,n),
      mk('BBC فارسی','bbc','حمله هوایی به تهران و اصفهان؛ شاهدان از انفجار در چند شهر خبر می‌دهند','ساعاتی پیش صدای انفجار در تهران و اصفهان شنیده شد. شاهدان می‌گویند حمله هوایی چند شهر را هدف قرار داد.',3,n),
    ],
  },
};
const api = { SCENARIOS };
if (typeof module !== 'undefined' && module.exports) module.exports = api;
root.DemoData = api;
})(typeof window !== 'undefined' ? window : globalThis);
